function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["post-loan-post-loan-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppComponentsImageUploadImageUploadComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-grid>\n    <ion-row *ngFor=\"let uploadFile of uploadFiles\">\n        <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" class=\"ion-float-center\">\n            <ion-item>\n                <div class=\"container\" *ngIf=\"uploadFile.filePath\">\n                    <img [src]=\"uploadFile.filePath | sanitizer\" />\n                    <button\n                        class=\"btn\"\n                        (click)=\"removeImage(uploadFile.ImageType)\"\n                    >\n                        X\n                    </button>\n                </div>\n            </ion-item>\n            <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                    Upload/Browse for {{ uploadFile.name }}\n                    <ion-text\n                        *ngIf=\"uploadFile.required\"\n                        ion-text\n                        color=\"danger\"\n                        >*</ion-text\n                    >\n                </ion-label>\n                <ion-input\n                    type=\"file\"\n                    accept=\"image/*\"\n                    (change)=\"\n                        getImage(uploadFile.ImageType, $event);\n                        sendThatFormIsValid()\n                    \"\n                    [attr.id]=\"uploadFile.ImageType\"\n                ></ion-input>\n            </ion-item>\n        </ion-col>\n    </ion-row>\n</ion-grid>\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPostLoanPostLoanPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [color]=\"'primary'\">\n        <ion-buttons slot=\"end\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title class=\"ion-text-center\">Post A Loan</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\">\n                <form\n                    [formGroup]=\"requestLoanForm\"\n                    (submit)=\"postLoan(requestLoanForm)\"\n                >\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Staff ID <ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"staffid\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Name of Client\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"clientName\"\n                        ></ion-input>\n                    </ion-item>\n\n                    <ion-list>\n                        <ion-label>Loans</ion-label>\n                        <ion-item *ngFor=\"let activeLoan of activeLoans\">\n                            <ion-checkbox\n                                slot=\"start\"\n                                (click)=\"getLoan(activeLoan, $event)\"\n                            ></ion-checkbox>\n                            <ion-label\n                                >{{activeLoan.Loan_No}} |\n                                {{activeLoan.ReplacementAmountDue}}</ion-label\n                            >\n                        </ion-item>\n                    </ion-list>\n\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Loan Amount<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"number\"\n                            formControlName=\"grossAmount\"\n                            [min]=\"whichIsbigger()\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Existing Loan Balance\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"existingBalance\"\n                            [value]=\"replacementBalance\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Tenor\n                        </ion-label>\n                        <ion-input\n                            type=\"number\"\n                            formControlName=\"tenor\"\n                            max=\"{{eligibilityData.Tenor | numberFilter}}\"\n                            min=\"0\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Payment Number<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"paymobileNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Mode of Payment<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentMethod\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let paymentMethod of paymentMethods\"\n                                [value]=\"paymentMethod.PaymentMethodName\"\n                                >{{paymentMethod.PaymentMethodName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose Loan Type<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"loantype\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let loanType of loanTypes\"\n                                [value]=\"loanType\"\n                                >{{loanType}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose Payment Branch<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentBranch\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let branch of branches\"\n                                [value]=\"branch.BranchName\"\n                                >{{branch.BranchName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Account Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"bankAccountNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose altenate Payment Branch\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentBranchAlt\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let branch of branches\"\n                                [value]=\"branch.BranchName\"\n                                >{{branch.BranchName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose altenate Payment Mode\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentMethodAlt\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let paymentMethod of paymentMethods\"\n                                [value]=\"paymentMethod.PaymentMethodName\"\n                                >{{paymentMethod.PaymentMethodName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Altenate Payment Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"paymobileNumberAlt\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Altenate Account Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"bankAccountNumberAlt\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Primary Contact Number<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"contactNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Mandate Number<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"mandatenumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Second Mandate Number<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"mandatenumber2\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Loan Advance Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"loanadvancenumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Authority Note Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"authoritynote\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            ID Card Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"idcard\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            TIN Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"tinNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Who does the deal belong to?<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"DealDPCode\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let teamMember of teamMembers\"\n                                [value]=\"teamMember.Code\"\n                                >{{teamMember.Name}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Who took the selfie?<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"selfieDPCode\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let teamMember of teamMembers\"\n                                [value]=\"teamMember.Code\"\n                                >{{teamMember.Name}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Afoordability\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"affordability\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Selfie Token<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"selfieToken\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Comments\n                        </ion-label>\n                        <ion-textarea\n                            type=\"text\"\n                            formControlName=\"comments\"\n                        ></ion-textarea>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Payment Name\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"PaymentName\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-row>\n                        <ion-col>\n                            <app-image-upload></app-image-upload>\n                        </ion-col>\n                    </ion-row>\n                    <ion-row>\n                        <ion-col [sizeMd]=\"6\" [offsetMd]=\"3\">\n                            <ion-button\n                                type=\"submit\"\n                                [disabled]=\"requestLoanForm.invalid && !isValid\"\n                                [expand]=\"'full'\"\n                                >Post Loan</ion-button\n                            >\n                        </ion-col>\n                    </ion-row>\n                </form>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/components/component/component.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/components/component/component.module.ts ***!
    \**********************************************************/

  /*! exports provided: ComponentModule */

  /***/
  function srcAppComponentsComponentComponentModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ComponentModule", function () {
      return ComponentModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../pipes/pipes/pipes.module */
    "./src/app/pipes/pipes/pipes.module.ts");
    /* harmony import */


    var _image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./../image-upload/image-upload.component */
    "./src/app/components/image-upload/image-upload.component.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var ComponentModule = function ComponentModule() {
      _classCallCheck(this, ComponentModule);
    };

    ComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
      declarations: [_image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__["ImageUploadComponent"]],
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__["PipesModule"]],
      exports: [_image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__["ImageUploadComponent"]],
      providers: []
    })], ComponentModule);
    /***/
  },

  /***/
  "./src/app/components/image-upload/image-upload.component.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/components/image-upload/image-upload.component.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppComponentsImageUploadImageUploadComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* Container needed to position the button. Adjust the width as needed */\n.container {\n  position: relative;\n  width: 50%;\n}\n/* Make the image responsive */\n.container img {\n  width: 100%;\n  height: auto;\n}\n/* Style the button and place it in the middle of the container/image */\n.container .btn {\n  position: absolute;\n  top: 5%;\n  left: 85%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  -ms-transform: translate(-50%, -50%);\n  background-color: #555;\n  color: white;\n  font-size: 16px;\n  padding: 12px 24px;\n  border: none;\n  cursor: pointer;\n  border-radius: 5px;\n}\n.container .btn:hover {\n  background-color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9pbWFnZS11cGxvYWQvRTpcXERBTEVYIENPREVcXGRwQXBwMi9zcmNcXGFwcFxcY29tcG9uZW50c1xcaW1hZ2UtdXBsb2FkXFxpbWFnZS11cGxvYWQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvaW1hZ2UtdXBsb2FkL2ltYWdlLXVwbG9hZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3RUFBQTtBQUNBO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0FDQ0o7QURFQSw4QkFBQTtBQUNBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNDSjtBREVBLHVFQUFBO0FBQ0E7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxTQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtFQUNBLG9DQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0NKO0FERUE7RUFDSSx1QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9pbWFnZS11cGxvYWQvaW1hZ2UtdXBsb2FkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29udGFpbmVyIG5lZWRlZCB0byBwb3NpdGlvbiB0aGUgYnV0dG9uLiBBZGp1c3QgdGhlIHdpZHRoIGFzIG5lZWRlZCAqL1xyXG4uY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi8qIE1ha2UgdGhlIGltYWdlIHJlc3BvbnNpdmUgKi9cclxuLmNvbnRhaW5lciBpbWcge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi8qIFN0eWxlIHRoZSBidXR0b24gYW5kIHBsYWNlIGl0IGluIHRoZSBtaWRkbGUgb2YgdGhlIGNvbnRhaW5lci9pbWFnZSAqL1xyXG4uY29udGFpbmVyIC5idG4ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1JTtcclxuICAgIGxlZnQ6IDg1JTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzU1NTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHBhZGRpbmc6IDEycHggMjRweDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxufVxyXG5cclxuLmNvbnRhaW5lciAuYnRuOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG59XHJcbiIsIi8qIENvbnRhaW5lciBuZWVkZWQgdG8gcG9zaXRpb24gdGhlIGJ1dHRvbi4gQWRqdXN0IHRoZSB3aWR0aCBhcyBuZWVkZWQgKi9cbi5jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi8qIE1ha2UgdGhlIGltYWdlIHJlc3BvbnNpdmUgKi9cbi5jb250YWluZXIgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLyogU3R5bGUgdGhlIGJ1dHRvbiBhbmQgcGxhY2UgaXQgaW4gdGhlIG1pZGRsZSBvZiB0aGUgY29udGFpbmVyL2ltYWdlICovXG4uY29udGFpbmVyIC5idG4ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNSU7XG4gIGxlZnQ6IDg1JTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzU1NTtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHBhZGRpbmc6IDEycHggMjRweDtcbiAgYm9yZGVyOiBub25lO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLmNvbnRhaW5lciAuYnRuOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/components/image-upload/image-upload.component.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/components/image-upload/image-upload.component.ts ***!
    \*******************************************************************/

  /*! exports provided: ImageUploadComponent */

  /***/
  function srcAppComponentsImageUploadImageUploadComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImageUploadComponent", function () {
      return ImageUploadComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _image_upload_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./image-upload.service */
    "./src/app/components/image-upload/image-upload.service.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/post-loan/post-loan.service */
    "./src/app/post-loan/post-loan.service.ts");
    /* harmony import */


    var src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/shared/shared.service */
    "./src/app/shared/shared.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");

    var ImageUploadComponent =
    /*#__PURE__*/
    function () {
      function ImageUploadComponent(imageUploadService, router, postLoanService, shared) {
        _classCallCheck(this, ImageUploadComponent);

        this.imageUploadService = imageUploadService;
        this.router = router;
        this.postLoanService = postLoanService;
        this.shared = shared;
        this.uploadFiles = [{
          ImageType: 'SELFIE',
          file: null,
          filePath: null,
          required: true,
          uploaded: false,
          name: 'Selfie'
        }, {
          ImageType: 'FORMA',
          file: null,
          filePath: null,
          required: true,
          uploaded: false,
          name: 'Form A'
        }, {
          ImageType: 'MANDATE',
          file: null,
          filePath: null,
          required: false,
          uploaded: false,
          name: 'Mandate Form'
        }, {
          ImageType: 'TRANSFER',
          file: null,
          filePath: null,
          required: false,
          uploaded: false,
          name: 'Transfer Letter'
        }, {
          ImageType: 'LOANADVANCE',
          file: null,
          filePath: null,
          required: false,
          uploaded: false,
          name: 'Loan Advance'
        }, {
          ImageType: 'AUTHORITYNOTE',
          file: null,
          filePath: null,
          required: false,
          uploaded: false,
          name: 'Authority Note'
        }, {
          ImageType: 'PASSPORT',
          file: null,
          filePath: null,
          required: false,
          uploaded: false,
          name: 'Passport Picture'
        }];
      }

      _createClass(ImageUploadComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.imageUploadService.startImageUpload.subscribe(function (id) {
            if (id) {
              // console.log('event recieved');
              _this.uploadImagesToServerBulk(id, _this.uploadFiles);
            }
          });
        }
      }, {
        key: "getImage",
        value: function getImage(id, event) {
          var files = event.target.files;

          if (files) {
            console.log(files);

            switch (files.item(0).size > 1024 * 1024 * 2) {
              case true:
                this.shared.presentToast('File is larger than 2MB');
                event.target.value = '';
                break;

              default:
                var output = URL.createObjectURL(files.item(0));
                this.uploadFiles[this.findObjectFromArray(id)].file = files.item(0);
                this.uploadFiles[this.findObjectFromArray(id)].filePath = output;
                break;
            }
          } else {
            this.uploadFiles[this.findObjectFromArray(id)].filePath = null;
            this.uploadFiles[this.findObjectFromArray(id)].file = null;
          } // console.log(this.uploadFiles, 'array');

        } //  checking to see that all my required images are available

      }, {
        key: "sendThatFormIsValid",
        value: function sendThatFormIsValid() {
          this.imageUploadService.allRequiredImagesUploaded.emit(this.formisValid(this.uploadFiles));
        }
      }, {
        key: "formisValid",
        value: function formisValid(obj) {
          return obj[0].required && obj[0].filePath && obj[1].filePath && obj[1].required;
        }
      }, {
        key: "findObjectFromArray",
        value: function findObjectFromArray(id) {
          var value = this.uploadFiles.findIndex(function (object) {
            return object.ImageType === id;
          });
          return value;
        }
      }, {
        key: "removeImage",
        value: function removeImage(id) {
          this.uploadFiles[this.findObjectFromArray(id)].filePath = null;
          this.uploadFiles[this.findObjectFromArray(id)].file = null;
        }
      }, {
        key: "uploadImagesToServer",
        value: function uploadImagesToServer(id) {
          var _this2 = this;

          this.uploadFiles.forEach(function (uploadFile) {
            if (uploadFile.filePath) {
              var imageResponse = {
                id: id,
                Image: uploadFile.file,
                Type: uploadFile.ImageType
              };

              _this2.imageUploadService.updateImage(id, imageResponse).subscribe(function (response) {
                console.log(response);
                uploadFile.uploaded = response.Status;
              });
            }
          });
          var selectedImages = this.uploadFiles.filter(function (item) {
            return item.filePath;
          });
          sessionStorage.setItem('imageResponse', JSON.stringify(selectedImages)); // this.postLoanService.loading.dismiss();

          this.router.navigate(['loan-posting-confirmation']);
        }
      }, {
        key: "uploadImagesToServerBulk",
        value: function uploadImagesToServerBulk(id, filestoUpload) {
          var _this3 = this;

          var results = this.filterForContentToUpload(filestoUpload); //  console.log(results, 'filter results');

          this.imageUploadService.attachImage(id, results).subscribe(function (event) {
            switch (event.type) {
              case _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].UploadProgress:
                console.log("Upload Progress ".concat((Math.round(event.loaded / event.total) * 100).toString(), "%"));
                break;

              case _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].Response:
                console.log(_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].Response, 'httpResponse');

                _this3.shared.presentToast('Upload Successful');

                _this3.router.navigate(['loan-posting-confirmation']);

                _this3.postLoanService.dismiss();

            }
          }, function () {
            _this3.shared.presentToast('Failed to upload');

            _this3.postLoanService.dismiss();
          });
          var selectedImages = this.uploadFiles.filter(function (item) {
            return item.filePath;
          });
          sessionStorage.setItem('imageResponse', JSON.stringify(selectedImages)); // this.postLoanService.loading.dismiss();
        }
      }, {
        key: "filterForContentToUpload",
        value: function filterForContentToUpload(filestoUpload) {
          var filterObject = function filterObject(file) {
            return file.file;
          };

          return filestoUpload.filter(filterObject);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.imageUploadService.startImageUpload.unsubscribe();
        }
      }, {
        key: "convertToBase64",
        value: function convertToBase64(file) {
          return new Promise(function (resolve, reject) {
            var reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = function () {
              var result = reader.result.toString().split(',')[1];
              resolve(result);
            };

            reader.onerror = function (error) {
              return reject(error);
            };
          });
        }
      }]);

      return ImageUploadComponent;
    }();

    ImageUploadComponent.ctorParameters = function () {
      return [{
        type: _image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"]
      }, {
        type: src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__["SharedService"]
      }];
    };

    ImageUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-image-upload',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./image-upload.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./image-upload.component.scss */
      "./src/app/components/image-upload/image-upload.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"], src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__["SharedService"]])], ImageUploadComponent);
    /***/
  },

  /***/
  "./src/app/components/image-upload/image-upload.service.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/components/image-upload/image-upload.service.ts ***!
    \*****************************************************************/

  /*! exports provided: ImageUploadService */

  /***/
  function srcAppComponentsImageUploadImageUploadServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImageUploadService", function () {
      return ImageUploadService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var ImageUploadService =
    /*#__PURE__*/
    function () {
      function ImageUploadService(http) {
        _classCallCheck(this, ImageUploadService);

        this.http = http;
        this.startImageUpload = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.allRequiredImagesUploaded = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
          'Content-Type': 'multipart/form-data;',
          Accept: '*/*'
        });
      }

      _createClass(ImageUploadService, [{
        key: "updateImage",
        value: function updateImage(id, imageResponse) {
          var httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('id', id);
          var options = {
            params: httpParams
          };
          return this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/mobile/updateimagesingle"), imageResponse, options);
        }
      }, {
        key: "attachImage",
        value: function attachImage(id, body) {
          // setup query parameters
          var httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('paymentRequestId', id); // setup formdata for images

          var fd = new FormData();
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = body[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var file = _step.value;
              console.log(file, 'files');
              fd.append(file.ImageType, new Blob([file.file], {
                type: file.file.type
              }), file.file.name);
            } // console.log(fd);

          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }

          return this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/mobile/attachImages"), fd, {
            params: httpParams,
            reportProgress: true,
            observe: 'events'
          });
        }
      }]);

      return ImageUploadService;
    }();

    ImageUploadService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    ImageUploadService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], ImageUploadService);
    /***/
  },

  /***/
  "./src/app/post-loan/post-loan.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/post-loan/post-loan.module.ts ***!
    \***********************************************/

  /*! exports provided: PostLoanPageModule */

  /***/
  function srcAppPostLoanPostLoanModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PostLoanPageModule", function () {
      return PostLoanPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _components_component_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../components/component/component.module */
    "./src/app/components/component/component.module.ts");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _post_loan_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./post-loan.page */
    "./src/app/post-loan/post-loan.page.ts");
    /* harmony import */


    var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../pipes/pipes/pipes.module */
    "./src/app/pipes/pipes/pipes.module.ts");

    var routes = [{
      path: '',
      component: _post_loan_page__WEBPACK_IMPORTED_MODULE_7__["PostLoanPage"]
    }];

    var PostLoanPageModule = function PostLoanPageModule() {
      _classCallCheck(this, PostLoanPageModule);
    };

    PostLoanPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"], _components_component_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes), _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"]],
      declarations: [_post_loan_page__WEBPACK_IMPORTED_MODULE_7__["PostLoanPage"]]
    })], PostLoanPageModule);
    /***/
  },

  /***/
  "./src/app/post-loan/post-loan.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/post-loan/post-loan.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppPostLoanPostLoanPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3QtbG9hbi9wb3N0LWxvYW4ucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/post-loan/post-loan.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/post-loan/post-loan.page.ts ***!
    \*********************************************/

  /*! exports provided: PostLoanPage */

  /***/
  function srcAppPostLoanPostLoanPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PostLoanPage", function () {
      return PostLoanPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../components/image-upload/image-upload.service */
    "./src/app/components/image-upload/image-upload.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _post_loan_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./post-loan.service */
    "./src/app/post-loan/post-loan.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var PostLoanPage =
    /*#__PURE__*/
    function () {
      function PostLoanPage(fb, postLoanService, imageUploadService) {
        _classCallCheck(this, PostLoanPage);

        this.fb = fb;
        this.postLoanService = postLoanService;
        this.imageUploadService = imageUploadService;
        this.loanTypes = ['DALEX', 'SNAP', 'SWIFT'];
        this.replacementBalance = 0;
        this.replacementLoanArray = [];
        this.loanTenors = [3, 6, 12, 18, 24, 36, 48, 54];
      }

      _createClass(PostLoanPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.userInfo = JSON.parse(sessionStorage.getItem('userInfo')); // check replacement balance
          // this.checkForReplacementBalance();
          // get eligiblity Data

          this.eligibilityData = JSON.parse(sessionStorage.getItem('eligibilityData'));

          if (this.imageUploadService.allRequiredImagesUploaded.observers.length < 1) {
            this.subscribeToImageEvent();
          }

          this.activeLoans = JSON.parse(sessionStorage.getItem('activeloans'));
          this.getPaymentMethods();
          this.getBranches();
          this.requestLoanForm = this.fb.group({
            staffid: [this.eligibilityData.EmployeeID, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            grossAmount: [500, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(this.whichIsbigger())])],
            netAmount: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            existingBalance: [this.replacementBalance, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            tenor: [parseInt(this.eligibilityData.Tenor, 10), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].max(parseInt(this.eligibilityData.Tenor, 10)), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0)])],
            loantype: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            paymentBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            paymentMethod: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            DealDPCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            contactNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10)])],
            paymobileNumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10)])],
            selfieDPCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            TLCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            bankAccountNumber: [],
            clientName: [this.eligibilityData.FullName, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            mandatenumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            mandatenumber2: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            loanadvancenumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            authoritynote: [''],
            tinNumber: [''],
            idcard: [''],
            employeetypeid: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            affordability: [''],
            paymentBranchAlt: [''],
            paymentNumberAlt: [''],
            paymentMethodAlt: [''],
            bankAccountNumberAlt: [''],
            PaymentName: [''],
            paymobileNumberAlt: [''],
            comments: [''],
            createdBy: [this.userInfo[6].Value],
            selfieToken: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
          });
        }
      }, {
        key: "getPaymentMethods",
        value: function getPaymentMethods() {
          var _this4 = this;

          this.postLoanService.getPaymentMethods().subscribe(function (response) {
            _this4.paymentMethods = response;
          }, function (err) {
            console.log(err);
          });
        }
      }, {
        key: "getBranches",
        value: function getBranches() {
          var _this5 = this;

          this.postLoanService.getBranches().subscribe(function (response) {
            _this5.branches = response;
          }, function (err) {
            console.log(err);
          });
        }
      }, {
        key: "whichIsbigger",
        value: function whichIsbigger() {
          return Math.max(this.replacementBalance + 500, 500);
        }
      }, {
        key: "postLoan",
        value: function postLoan(form) {
          var _this6 = this;

          var netAmount = form.value.grossAmount - this.replacementBalance;
          sessionStorage.setItem('netAmount', netAmount.toString());
          this.postLoanService.requestLoan(form.value).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["throttleTime"])(10000)).subscribe(function (response) {
            var responseData = JSON.parse(response.Data);
            sessionStorage.setItem('loanRequestResponse', response.Data);
            console.log(response, 'loan posting response'); // this.postLoanService.presentLoadingWithOptions('Posting Loan');

            _this6.postLoanService.present();

            if (_this6.replacementLoanArray.length > 0) {
              _this6.compileLoan(_this6.replacementLoanArray, responseData.Id, netAmount);
            }

            _this6.imageUploadService.startImageUpload.emit(responseData.Id);
          }); // this.imageUploadService.startImageUpload.emit('718');
        }
      }, {
        key: "checkForReplacementBalance",
        value: function checkForReplacementBalance() {
          var replacementLoansFromNav = this.replacementLoanArray;

          if (replacementLoansFromNav.length > 0) {
            this.replacementBalance = replacementLoansFromNav.map(function (loans) {
              return loans.ReplacementAmountDue;
            }).reduce(function (prev, current) {
              return prev + current;
            }, 0);
          } else {
            this.replacementBalance = 0;
          } // console.log(this.replacementBalance);

        }
      }, {
        key: "getLoan",
        value: function getLoan(loan, e) {
          var loantoReplace = loan;
          var index = this.replacementLoanArray.indexOf(loantoReplace);

          if (!e.target.checked) {
            this.replacementLoanArray.push(loantoReplace);
          } else {
            this.replacementLoanArray.splice(index, 1);
          }

          this.checkForReplacementBalance();
          console.log(this.replacementLoanArray);
        }
      }, {
        key: "compileLoan",
        value: function compileLoan(loan, id, netAmount) {
          var replacementLoansChosen = [];
          var loantoReplace = {};
          loan.forEach(function (element) {
            loantoReplace.Id = id;
            loantoReplace.NavLoanId = element.Loan_No;
            loantoReplace.NetAmount = netAmount;
            replacementLoansChosen.push(loantoReplace);
          });
          console.log(replacementLoansChosen);
          this.postLoanService.configureNetAmount(replacementLoansChosen).subscribe(function (response) {
            console.log(response, 'replacement chosen');
          });
        } // get team members

      }, {
        key: "getTeamMembers",
        value: function getTeamMembers() {
          var _this7 = this;

          this.postLoanService.getTeamMembers().subscribe(function (response) {
            _this7.teamMembers = response; // console.log(this.teamMembers, 'team members');
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.imageUploadService.allRequiredImagesUploaded.unsubscribe();
        }
      }, {
        key: "ionViewWillLeave",
        value: function ionViewWillLeave() {
          this.imageUploadService.allRequiredImagesUploaded.unsubscribe();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.getTeamMembers();
        }
      }, {
        key: "subscribeToImageEvent",
        value: function subscribeToImageEvent() {
          var _this8 = this;

          // subscribe to form is required mages upload event
          this.imageUploadService.allRequiredImagesUploaded.subscribe(function (isValid) {
            _this8.isValid = isValid; // console.log(
            //     this.isValid,
            //     'this is what the image service emits'
            // ); not needed
          });
        }
      }]);

      return PostLoanPage;
    }();

    PostLoanPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"]
      }, {
        type: _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"]
      }];
    };

    PostLoanPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
      selector: 'app-post-loan',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./post-loan.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./post-loan.page.scss */
      "./src/app/post-loan/post-loan.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"], _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"]])], PostLoanPage);
    /***/
  },

  /***/
  "./src/app/post-loan/post-loan.service.ts":
  /*!************************************************!*\
    !*** ./src/app/post-loan/post-loan.service.ts ***!
    \************************************************/

  /*! exports provided: PostLoanService */

  /***/
  function srcAppPostLoanPostLoanServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PostLoanService", function () {
      return PostLoanService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var PostLoanService =
    /*#__PURE__*/
    function () {
      function PostLoanService(http, loadingController) {
        _classCallCheck(this, PostLoanService);

        this.http = http;
        this.loadingController = loadingController;
        this.isLoading = false;
      }

      _createClass(PostLoanService, [{
        key: "getPaymentMethods",
        value: function getPaymentMethods() {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/paymentMethods"));
        }
      }, {
        key: "getBranches",
        value: function getBranches() {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/web/getBranch"));
        }
      }, {
        key: "requestLoan",
        value: function requestLoan(request) {
          return this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/mobile/requestloan"), request);
        }
      }, {
        key: "presentLoadingWithOptions",
        value: function presentLoadingWithOptions(message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: message,
                      translucent: true
                    });

                  case 2:
                    this.loading = _context.sent;
                    _context.next = 5;
                    return this.loading.present();

                  case 5:
                    return _context.abrupt("return", _context.sent);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "present",
        value: function present() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee2() {
            var _this9 = this;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    this.isLoading = true;
                    _context2.next = 3;
                    return this.loadingController.create({
                      translucent: true,
                      message: 'Posting Loan'
                    }).then(function (a) {
                      a.present().then(function () {
                        console.log('presented');

                        if (!_this9.isLoading) {
                          a.dismiss().then(function () {
                            return console.log('abort presenting');
                          });
                        }
                      });
                    });

                  case 3:
                    return _context2.abrupt("return", _context2.sent);

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "dismiss",
        value: function dismiss() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0,
          /*#__PURE__*/
          regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.isLoading = false;
                    _context3.next = 3;
                    return this.loadingController.dismiss().then(function () {
                      return console.log('dismissed');
                    });

                  case 3:
                    return _context3.abrupt("return", _context3.sent);

                  case 4:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "configureNetAmount",
        value: function configureNetAmount(loanRequests) {
          return this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/mobile/setnavloanidbulk"), loanRequests);
        } // get team members

      }, {
        key: "getTeamMembers",
        value: function getTeamMembers() {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/dalexpaddies/TeamMembers"));
        }
      }]);

      return PostLoanService;
    }();

    PostLoanService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }];
    };

    PostLoanService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])], PostLoanService);
    /***/
  }
}]);
//# sourceMappingURL=post-loan-post-loan-module-es5.js.map