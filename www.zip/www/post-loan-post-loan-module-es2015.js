(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["post-loan-post-loan-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-grid>\n    <ion-row *ngFor=\"let uploadFile of uploadFiles\">\n        <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" class=\"ion-float-center\">\n            <ion-item>\n                <div class=\"container\" *ngIf=\"uploadFile.filePath\">\n                    <img [src]=\"uploadFile.filePath | sanitizer\" />\n                    <button\n                        class=\"btn\"\n                        (click)=\"removeImage(uploadFile.ImageType)\"\n                    >\n                        X\n                    </button>\n                </div>\n            </ion-item>\n            <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                    Upload/Browse for {{ uploadFile.name }}\n                    <ion-text\n                        *ngIf=\"uploadFile.required\"\n                        ion-text\n                        color=\"danger\"\n                        >*</ion-text\n                    >\n                </ion-label>\n                <ion-input\n                    type=\"file\"\n                    accept=\"image/*\"\n                    (change)=\"\n                        getImage(uploadFile.ImageType, $event);\n                        sendThatFormIsValid()\n                    \"\n                    [attr.id]=\"uploadFile.ImageType\"\n                ></ion-input>\n            </ion-item>\n        </ion-col>\n    </ion-row>\n</ion-grid>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [color]=\"'primary'\">\n        <ion-buttons slot=\"end\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title class=\"ion-text-center\">Post A Loan</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\">\n                <form\n                    [formGroup]=\"requestLoanForm\"\n                    (submit)=\"postLoan(requestLoanForm)\"\n                >\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Staff ID <ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"staffid\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Name of Client\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"clientName\"\n                        ></ion-input>\n                    </ion-item>\n\n                    <ion-list>\n                        <ion-label>Loans</ion-label>\n                        <ion-item *ngFor=\"let activeLoan of activeLoans\">\n                            <ion-checkbox\n                                slot=\"start\"\n                                (click)=\"getLoan(activeLoan, $event)\"\n                            ></ion-checkbox>\n                            <ion-label\n                                >{{activeLoan.Loan_No}} |\n                                {{activeLoan.ReplacementAmountDue}}</ion-label\n                            >\n                        </ion-item>\n                    </ion-list>\n\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Loan Amount<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"number\"\n                            formControlName=\"grossAmount\"\n                            [min]=\"whichIsbigger()\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Existing Loan Balance\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            readonly\n                            formControlName=\"existingBalance\"\n                            [value]=\"replacementBalance\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Tenor\n                        </ion-label>\n                        <ion-input\n                            type=\"number\"\n                            formControlName=\"tenor\"\n                            max=\"{{eligibilityData.Tenor | numberFilter}}\"\n                            min=\"0\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Payment Number<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"paymobileNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Mode of Payment<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentMethod\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let paymentMethod of paymentMethods\"\n                                [value]=\"paymentMethod.PaymentMethodName\"\n                                >{{paymentMethod.PaymentMethodName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose Loan Type<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"loantype\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let loanType of loanTypes\"\n                                [value]=\"loanType\"\n                                >{{loanType}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose Payment Branch<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentBranch\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let branch of branches\"\n                                [value]=\"branch.BranchName\"\n                                >{{branch.BranchName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Account Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"bankAccountNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose altenate Payment Branch\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentBranchAlt\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let branch of branches\"\n                                [value]=\"branch.BranchName\"\n                                >{{branch.BranchName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Choose altenate Payment Mode\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"paymentMethodAlt\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let paymentMethod of paymentMethods\"\n                                [value]=\"paymentMethod.PaymentMethodName\"\n                                >{{paymentMethod.PaymentMethodName}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Altenate Payment Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"paymobileNumberAlt\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Altenate Account Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"bankAccountNumberAlt\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Primary Contact Number<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"contactNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Mandate Number<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"mandatenumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Second Mandate Number<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"mandatenumber2\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Loan Advance Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"loanadvancenumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Authority Note Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"authoritynote\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            ID Card Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"idcard\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            TIN Number\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"tinNumber\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Who does the deal belong to?<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"DealDPCode\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let teamMember of teamMembers\"\n                                [value]=\"teamMember.Code\"\n                                >{{teamMember.Name}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Who took the selfie?<ion-text color=\"danger\"\n                                >*</ion-text\n                            >\n                        </ion-label>\n                        <ion-select\n                            interface=\"popover\"\n                            type=\"text\"\n                            formControlName=\"selfieDPCode\"\n                        >\n                            <ion-select-option\n                                *ngFor=\"let teamMember of teamMembers\"\n                                [value]=\"teamMember.Code\"\n                                >{{teamMember.Name}}</ion-select-option\n                            >\n                        </ion-select>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Afoordability\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"affordability\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Selfie Token<ion-text color=\"danger\">*</ion-text>\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"selfieToken\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Comments\n                        </ion-label>\n                        <ion-textarea\n                            type=\"text\"\n                            formControlName=\"comments\"\n                        ></ion-textarea>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\">\n                            Payment Name\n                        </ion-label>\n                        <ion-input\n                            type=\"text\"\n                            formControlName=\"PaymentName\"\n                        ></ion-input>\n                    </ion-item>\n                    <ion-row>\n                        <ion-col>\n                            <app-image-upload></app-image-upload>\n                        </ion-col>\n                    </ion-row>\n                    <ion-row>\n                        <ion-col [sizeMd]=\"6\" [offsetMd]=\"3\">\n                            <ion-button\n                                type=\"submit\"\n                                [disabled]=\"requestLoanForm.invalid && !isValid\"\n                                [expand]=\"'full'\"\n                                >Post Loan</ion-button\n                            >\n                        </ion-col>\n                    </ion-row>\n                </form>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/components/component/component.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/components/component/component.module.ts ***!
  \**********************************************************/
/*! exports provided: ComponentModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComponentModule", function() { return ComponentModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../pipes/pipes/pipes.module */ "./src/app/pipes/pipes/pipes.module.ts");
/* harmony import */ var _image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../image-upload/image-upload.component */ "./src/app/components/image-upload/image-upload.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");






let ComponentModule = class ComponentModule {
};
ComponentModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        declarations: [_image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__["ImageUploadComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_1__["PipesModule"]],
        exports: [_image_upload_image_upload_component__WEBPACK_IMPORTED_MODULE_2__["ImageUploadComponent"]],
        providers: [],
    })
], ComponentModule);



/***/ }),

/***/ "./src/app/components/image-upload/image-upload.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/image-upload/image-upload.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* Container needed to position the button. Adjust the width as needed */\n.container {\n  position: relative;\n  width: 50%;\n}\n/* Make the image responsive */\n.container img {\n  width: 100%;\n  height: auto;\n}\n/* Style the button and place it in the middle of the container/image */\n.container .btn {\n  position: absolute;\n  top: 5%;\n  left: 85%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  -ms-transform: translate(-50%, -50%);\n  background-color: #555;\n  color: white;\n  font-size: 16px;\n  padding: 12px 24px;\n  border: none;\n  cursor: pointer;\n  border-radius: 5px;\n}\n.container .btn:hover {\n  background-color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9pbWFnZS11cGxvYWQvRTpcXERBTEVYIENPREVcXGRwQXBwMi9zcmNcXGFwcFxcY29tcG9uZW50c1xcaW1hZ2UtdXBsb2FkXFxpbWFnZS11cGxvYWQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL2NvbXBvbmVudHMvaW1hZ2UtdXBsb2FkL2ltYWdlLXVwbG9hZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx3RUFBQTtBQUNBO0VBQ0ksa0JBQUE7RUFDQSxVQUFBO0FDQ0o7QURFQSw4QkFBQTtBQUNBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNDSjtBREVBLHVFQUFBO0FBQ0E7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxTQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtFQUNBLG9DQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQ0NKO0FERUE7RUFDSSx1QkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvY29tcG9uZW50cy9pbWFnZS11cGxvYWQvaW1hZ2UtdXBsb2FkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ29udGFpbmVyIG5lZWRlZCB0byBwb3NpdGlvbiB0aGUgYnV0dG9uLiBBZGp1c3QgdGhlIHdpZHRoIGFzIG5lZWRlZCAqL1xyXG4uY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHdpZHRoOiA1MCU7XHJcbn1cclxuXHJcbi8qIE1ha2UgdGhlIGltYWdlIHJlc3BvbnNpdmUgKi9cclxuLmNvbnRhaW5lciBpbWcge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbn1cclxuXHJcbi8qIFN0eWxlIHRoZSBidXR0b24gYW5kIHBsYWNlIGl0IGluIHRoZSBtaWRkbGUgb2YgdGhlIGNvbnRhaW5lci9pbWFnZSAqL1xyXG4uY29udGFpbmVyIC5idG4ge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1JTtcclxuICAgIGxlZnQ6IDg1JTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgLW1zLXRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzU1NTtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHBhZGRpbmc6IDEycHggMjRweDtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxufVxyXG5cclxuLmNvbnRhaW5lciAuYnRuOmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG59XHJcbiIsIi8qIENvbnRhaW5lciBuZWVkZWQgdG8gcG9zaXRpb24gdGhlIGJ1dHRvbi4gQWRqdXN0IHRoZSB3aWR0aCBhcyBuZWVkZWQgKi9cbi5jb250YWluZXIge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHdpZHRoOiA1MCU7XG59XG5cbi8qIE1ha2UgdGhlIGltYWdlIHJlc3BvbnNpdmUgKi9cbi5jb250YWluZXIgaW1nIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogYXV0bztcbn1cblxuLyogU3R5bGUgdGhlIGJ1dHRvbiBhbmQgcGxhY2UgaXQgaW4gdGhlIG1pZGRsZSBvZiB0aGUgY29udGFpbmVyL2ltYWdlICovXG4uY29udGFpbmVyIC5idG4ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNSU7XG4gIGxlZnQ6IDg1JTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzU1NTtcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHBhZGRpbmc6IDEycHggMjRweDtcbiAgYm9yZGVyOiBub25lO1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLmNvbnRhaW5lciAuYnRuOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7XG59Il19 */");

/***/ }),

/***/ "./src/app/components/image-upload/image-upload.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/image-upload/image-upload.component.ts ***!
  \*******************************************************************/
/*! exports provided: ImageUploadComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageUploadComponent", function() { return ImageUploadComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _image_upload_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./image-upload.service */ "./src/app/components/image-upload/image-upload.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/post-loan/post-loan.service */ "./src/app/post-loan/post-loan.service.ts");
/* harmony import */ var src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/shared.service */ "./src/app/shared/shared.service.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");







let ImageUploadComponent = class ImageUploadComponent {
    constructor(imageUploadService, router, postLoanService, shared) {
        this.imageUploadService = imageUploadService;
        this.router = router;
        this.postLoanService = postLoanService;
        this.shared = shared;
        this.uploadFiles = [
            {
                ImageType: 'SELFIE',
                file: null,
                filePath: null,
                required: true,
                uploaded: false,
                name: 'Selfie',
            },
            {
                ImageType: 'FORMA',
                file: null,
                filePath: null,
                required: true,
                uploaded: false,
                name: 'Form A',
            },
            {
                ImageType: 'APPOINT',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'Appointment Letter',
            },
            {
                ImageType: 'TRANSFER',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'Transfer Letter',
            },
            {
                ImageType: 'LOANADVANCE',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'Loan Advance',
            },
            {
                ImageType: 'AUTHORITYNOTE',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'Authority Note',
            },
            {
                ImageType: 'PASSPORT',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'Passport Picture',
            },
            {
                ImageType: 'IDCARD',
                file: null,
                filePath: null,
                required: false,
                uploaded: false,
                name: 'ID Card',
            },
        ];
    }
    ngOnInit() {
        this.imageUploadService.startImageUpload.subscribe((id) => {
            if (id) {
                // console.log('event recieved');
                this.uploadImagesToServerBulk(id, this.uploadFiles);
            }
        });
    }
    getImage(id, event) {
        const files = event.target.files;
        if (files) {
            console.log(files);
            switch (files.item(0).size > 1024 * 1024 * 2) {
                case true:
                    this.shared.presentToast('File is larger than 2MB');
                    event.target.value = '';
                    break;
                default:
                    const output = URL.createObjectURL(files.item(0));
                    this.uploadFiles[this.findObjectFromArray(id)].file = files.item(0);
                    this.uploadFiles[this.findObjectFromArray(id)].filePath = output;
                    break;
            }
        }
        else {
            this.uploadFiles[this.findObjectFromArray(id)].filePath = null;
            this.uploadFiles[this.findObjectFromArray(id)].file = null;
        }
        // console.log(this.uploadFiles, 'array');
    }
    //  checking to see that all my required images are available
    sendThatFormIsValid() {
        this.imageUploadService.allRequiredImagesUploaded.emit(this.formisValid(this.uploadFiles));
    }
    formisValid(obj) {
        return (obj[0].required &&
            obj[0].filePath &&
            obj[1].filePath &&
            obj[1].required);
    }
    findObjectFromArray(id) {
        const value = this.uploadFiles.findIndex((object) => {
            return object.ImageType === id;
        });
        return value;
    }
    removeImage(id) {
        this.uploadFiles[this.findObjectFromArray(id)].filePath = null;
        this.uploadFiles[this.findObjectFromArray(id)].file = null;
    }
    uploadImagesToServer(id) {
        this.uploadFiles.forEach((uploadFile) => {
            if (uploadFile.filePath) {
                const imageResponse = {
                    id,
                    Image: uploadFile.file,
                    Type: uploadFile.ImageType,
                };
                this.imageUploadService
                    .updateImage(id, imageResponse)
                    .subscribe((response) => {
                    console.log(response);
                    uploadFile.uploaded = response.Status;
                });
            }
        });
        const selectedImages = this.uploadFiles.filter((item) => item.filePath);
        sessionStorage.setItem('imageResponse', JSON.stringify(selectedImages));
        // this.postLoanService.loading.dismiss();
        this.router.navigate(['loan-posting-confirmation']);
    }
    uploadImagesToServerBulk(id, filestoUpload) {
        const results = this.filterForContentToUpload(filestoUpload);
        //  console.log(results, 'filter results');
        this.imageUploadService.attachImage(id, results).subscribe((event) => {
            switch (event.type) {
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].UploadProgress:
                    console.log(`Upload Progress ${(Math.round(event.loaded / event.total) * 100).toString()}%`);
                    break;
                case _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].Response:
                    console.log(_angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpEventType"].Response, 'httpResponse');
                    this.shared.presentToast('Upload Successful');
                    this.router.navigate(['loan-posting-confirmation']);
                    this.postLoanService.dismiss();
            }
        }, () => {
            this.shared.presentToast('Failed to upload');
            this.postLoanService.dismiss();
        });
        const selectedImages = this.uploadFiles.filter((item) => item.filePath);
        sessionStorage.setItem('imageResponse', JSON.stringify(selectedImages));
        // this.postLoanService.loading.dismiss();
    }
    filterForContentToUpload(filestoUpload) {
        const filterObject = (file) => file.file;
        return filestoUpload.filter(filterObject);
    }
    ngOnDestroy() {
        this.imageUploadService.startImageUpload.unsubscribe();
    }
    convertToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                const result = reader.result.toString().split(',')[1];
                resolve(result);
            };
            reader.onerror = (error) => reject(error);
        });
    }
};
ImageUploadComponent.ctorParameters = () => [
    { type: _image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"] },
    { type: src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__["SharedService"] }
];
ImageUploadComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-image-upload',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./image-upload.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/components/image-upload/image-upload.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./image-upload.component.scss */ "./src/app/components/image-upload/image-upload.component.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        src_app_post_loan_post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"],
        src_app_shared_shared_service__WEBPACK_IMPORTED_MODULE_5__["SharedService"]])
], ImageUploadComponent);



/***/ }),

/***/ "./src/app/components/image-upload/image-upload.service.ts":
/*!*****************************************************************!*\
  !*** ./src/app/components/image-upload/image-upload.service.ts ***!
  \*****************************************************************/
/*! exports provided: ImageUploadService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImageUploadService", function() { return ImageUploadService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");




let ImageUploadService = class ImageUploadService {
    constructor(http) {
        this.http = http;
        this.startImageUpload = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.allRequiredImagesUploaded = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
            'Content-Type': 'multipart/form-data;',
            Accept: '*/*',
        });
    }
    updateImage(id, imageResponse) {
        const httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('id', id);
        const options = { params: httpParams };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/updateimagesingle`, imageResponse, options);
    }
    attachImage(id, body) {
        // setup query parameters
        const httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('paymentRequestId', id);
        // setup formdata for images
        const fd = new FormData();
        for (const file of body) {
            console.log(file, 'files');
            fd.append(file.ImageType, new Blob([file.file], { type: file.file.type }), file.file.name);
        }
        // console.log(fd);
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/attachImages`, fd, {
            params: httpParams,
            reportProgress: true,
            observe: 'events',
        });
    }
};
ImageUploadService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
ImageUploadService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], ImageUploadService);



/***/ }),

/***/ "./src/app/post-loan/post-loan.module.ts":
/*!***********************************************!*\
  !*** ./src/app/post-loan/post-loan.module.ts ***!
  \***********************************************/
/*! exports provided: PostLoanPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostLoanPageModule", function() { return PostLoanPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _components_component_component_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../components/component/component.module */ "./src/app/components/component/component.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _post_loan_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./post-loan.page */ "./src/app/post-loan/post-loan.page.ts");
/* harmony import */ var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../pipes/pipes/pipes.module */ "./src/app/pipes/pipes/pipes.module.ts");









const routes = [
    {
        path: '',
        component: _post_loan_page__WEBPACK_IMPORTED_MODULE_7__["PostLoanPage"],
    },
];
let PostLoanPageModule = class PostLoanPageModule {
};
PostLoanPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _components_component_component_module__WEBPACK_IMPORTED_MODULE_1__["ComponentModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild(routes),
            _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_8__["PipesModule"],
        ],
        declarations: [_post_loan_page__WEBPACK_IMPORTED_MODULE_7__["PostLoanPage"]],
    })
], PostLoanPageModule);



/***/ }),

/***/ "./src/app/post-loan/post-loan.page.scss":
/*!***********************************************!*\
  !*** ./src/app/post-loan/post-loan.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3QtbG9hbi9wb3N0LWxvYW4ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/post-loan/post-loan.page.ts":
/*!*********************************************!*\
  !*** ./src/app/post-loan/post-loan.page.ts ***!
  \*********************************************/
/*! exports provided: PostLoanPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostLoanPage", function() { return PostLoanPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../components/image-upload/image-upload.service */ "./src/app/components/image-upload/image-upload.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _post_loan_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./post-loan.service */ "./src/app/post-loan/post-loan.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");






let PostLoanPage = class PostLoanPage {
    constructor(fb, postLoanService, imageUploadService) {
        this.fb = fb;
        this.postLoanService = postLoanService;
        this.imageUploadService = imageUploadService;
        this.loanTypes = ['DALEX', 'SNAP', 'SWIFT'];
        this.replacementBalance = 0;
        this.replacementLoanArray = [];
        this.loanTenors = [3, 6, 12, 18, 24, 36, 48, 54];
    }
    ngOnInit() {
        this.userInfo = JSON.parse(sessionStorage.getItem('userInfo'));
        // check replacement balance
        // this.checkForReplacementBalance();
        // get eligiblity Data
        this.eligibilityData = JSON.parse(sessionStorage.getItem('eligibilityData'));
        if (this.imageUploadService.allRequiredImagesUploaded.observers.length <
            1) {
            this.subscribeToImageEvent();
        }
        this.activeLoans = JSON.parse(sessionStorage.getItem('activeloans'));
        this.getPaymentMethods();
        this.getBranches();
        this.requestLoanForm = this.fb.group({
            staffid: [this.eligibilityData.EmployeeID, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            grossAmount: [
                500,
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(this.whichIsbigger()),
                ]),
            ],
            netAmount: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            existingBalance: [this.replacementBalance, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            tenor: [
                parseInt(this.eligibilityData.Tenor, 10),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].max(parseInt(this.eligibilityData.Tenor, 10)),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0),
                ]),
            ],
            loantype: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            paymentBranch: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            paymentMethod: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            DealDPCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            contactNumber: [
                '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10),
                ]),
            ],
            paymobileNumber: [
                '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required,
                    _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].minLength(10),
                ]),
            ],
            selfieDPCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            TLCode: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            bankAccountNumber: [],
            clientName: [this.eligibilityData.FullName, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            mandatenumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            mandatenumber2: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            loanadvancenumber: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            authoritynote: [''],
            tinNumber: [''],
            idcard: [''],
            employeetypeid: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            affordability: [''],
            paymentBranchAlt: [''],
            paymentNumberAlt: [''],
            paymentMethodAlt: [''],
            bankAccountNumberAlt: [''],
            PaymentName: [''],
            paymobileNumberAlt: [''],
            comments: [''],
            createdBy: [this.userInfo[6].Value],
            selfieToken: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
        });
    }
    getPaymentMethods() {
        this.postLoanService.getPaymentMethods().subscribe((response) => {
            this.paymentMethods = response;
        }, (err) => {
            console.log(err);
        });
    }
    getBranches() {
        this.postLoanService.getBranches().subscribe((response) => {
            this.branches = response;
        }, (err) => {
            console.log(err);
        });
    }
    whichIsbigger() {
        return Math.max(this.replacementBalance + 500, 500);
    }
    postLoan(form) {
        const netAmount = form.value.grossAmount - this.replacementBalance;
        sessionStorage.setItem('netAmount', netAmount.toString());
        this.postLoanService
            .requestLoan(form.value)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["throttleTime"])(10000))
            .subscribe((response) => {
            const responseData = JSON.parse(response.Data);
            sessionStorage.setItem('loanRequestResponse', response.Data);
            console.log(response, 'loan posting response');
            // this.postLoanService.presentLoadingWithOptions('Posting Loan');
            this.postLoanService.present();
            if (this.replacementLoanArray.length > 0) {
                this.compileLoan(this.replacementLoanArray, responseData.Id, netAmount);
            }
            this.imageUploadService.startImageUpload.emit(responseData.Id);
        });
        // this.imageUploadService.startImageUpload.emit('718');
    }
    checkForReplacementBalance() {
        const replacementLoansFromNav = this
            .replacementLoanArray;
        if (replacementLoansFromNav.length > 0) {
            this.replacementBalance = replacementLoansFromNav
                .map((loans) => loans.ReplacementAmountDue)
                .reduce((prev, current) => prev + current, 0);
        }
        else {
            this.replacementBalance = 0;
        }
        // console.log(this.replacementBalance);
    }
    getLoan(loan, e) {
        const loantoReplace = loan;
        const index = this.replacementLoanArray.indexOf(loantoReplace);
        if (!e.target.checked) {
            this.replacementLoanArray.push(loantoReplace);
        }
        else {
            this.replacementLoanArray.splice(index, 1);
        }
        this.checkForReplacementBalance();
        console.log(this.replacementLoanArray);
    }
    compileLoan(loan, id, netAmount) {
        const replacementLoansChosen = [];
        const loantoReplace = {};
        loan.forEach((element) => {
            loantoReplace.Id = id;
            loantoReplace.NavLoanId = element.Loan_No;
            loantoReplace.NetAmount = netAmount;
            replacementLoansChosen.push(loantoReplace);
        });
        console.log(replacementLoansChosen);
        this.postLoanService
            .configureNetAmount(replacementLoansChosen)
            .subscribe((response) => {
            console.log(response, 'replacement chosen');
        });
    }
    // get team members
    getTeamMembers() {
        this.postLoanService.getTeamMembers().subscribe((response) => {
            this.teamMembers = response;
            // console.log(this.teamMembers, 'team members');
        });
    }
    ngOnDestroy() {
        this.imageUploadService.allRequiredImagesUploaded.unsubscribe();
    }
    ionViewWillLeave() {
        this.imageUploadService.allRequiredImagesUploaded.unsubscribe();
    }
    ionViewDidEnter() {
        this.getTeamMembers();
    }
    subscribeToImageEvent() {
        // subscribe to form is required mages upload event
        this.imageUploadService.allRequiredImagesUploaded.subscribe((isValid) => {
            this.isValid = isValid;
            // console.log(
            //     this.isValid,
            //     'this is what the image service emits'
            // ); not needed
        });
    }
};
PostLoanPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"] },
    { type: _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"] }
];
PostLoanPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-post-loan',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./post-loan.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/post-loan/post-loan.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./post-loan.page.scss */ "./src/app/post-loan/post-loan.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
        _post_loan_service__WEBPACK_IMPORTED_MODULE_4__["PostLoanService"],
        _components_image_upload_image_upload_service__WEBPACK_IMPORTED_MODULE_1__["ImageUploadService"]])
], PostLoanPage);



/***/ }),

/***/ "./src/app/post-loan/post-loan.service.ts":
/*!************************************************!*\
  !*** ./src/app/post-loan/post-loan.service.ts ***!
  \************************************************/
/*! exports provided: PostLoanService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostLoanService", function() { return PostLoanService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let PostLoanService = class PostLoanService {
    constructor(http, loadingController) {
        this.http = http;
        this.loadingController = loadingController;
        this.isLoading = false;
    }
    getPaymentMethods() {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/paymentMethods`);
    }
    getBranches() {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/web/getBranch`);
    }
    requestLoan(request) {
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/requestloan`, request);
    }
    presentLoadingWithOptions(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                message,
                translucent: true,
            });
            return yield this.loading.present();
        });
    }
    present() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = true;
            return yield this.loadingController
                .create({
                translucent: true,
                message: 'Posting Loan',
            })
                .then(a => {
                a.present().then(() => {
                    console.log('presented');
                    if (!this.isLoading) {
                        a.dismiss().then(() => console.log('abort presenting'));
                    }
                });
            });
        });
    }
    dismiss() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.isLoading = false;
            return yield this.loadingController
                .dismiss()
                .then(() => console.log('dismissed'));
        });
    }
    configureNetAmount(loanRequests) {
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/setnavloanidbulk`, loanRequests);
    }
    // get team members
    getTeamMembers() {
        return this.http.get(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/dalexpaddies/TeamMembers`);
    }
};
PostLoanService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
PostLoanService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]])
], PostLoanService);



/***/ })

}]);
//# sourceMappingURL=post-loan-post-loan-module-es2015.js.map