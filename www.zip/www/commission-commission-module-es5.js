function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["commission-commission-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/commission/commission.page.html":
  /*!***************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commission/commission.page.html ***!
    \***************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCommissionCommissionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [color]=\"'primary'\">\n        <ion-buttons slot=\"start\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title class=\"ion-text-center\">Commission</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\" [sizeLg]=\"12\" [offsetLg]=\"0\">\n                <ion-card>\n                    <ion-card-header>\n                        Commission: {{commissionBalance}}\n                    </ion-card-header>\n                    <ion-card-content>\n                        <ion-button\n                            [disabled]=\"commissionBalance < 1\"\n                            (click)=\"openWithdrawalForm()\"\n                            >Withdraw Funds</ion-button\n                        >\n                        <form\n                            *ngIf=\"withdrawalForm\"\n                            [formGroup]=\"commissionForm\"\n                            (submit)=\"enterWithdrawalAmount(commissionForm)\"\n                        >\n                            <ion-item>\n                                <ion-label [position]=\"'stacked'\"\n                                    >Enter Withdrawal Amount</ion-label\n                                >\n                                <ion-input\n                                    formControlName=\"amount\"\n                                    type=\"number\"\n                                    min=\"1\"\n                                ></ion-input>\n                            </ion-item>\n                            <ion-button\n                                type=\"submit\"\n                                [disabled]=\"commissionForm.invalid\"\n                                >Process</ion-button\n                            >\n                        </form>\n                    </ion-card-content>\n                </ion-card>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/commission/commission.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/commission/commission.module.ts ***!
    \*************************************************/

  /*! exports provided: CommissionPageModule */

  /***/
  function srcAppCommissionCommissionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionPageModule", function () {
      return CommissionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _commission_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./commission.page */
    "./src/app/commission/commission.page.ts");

    var routes = [{
      path: '',
      component: _commission_page__WEBPACK_IMPORTED_MODULE_6__["CommissionPage"]
    }];

    var CommissionPageModule = function CommissionPageModule() {
      _classCallCheck(this, CommissionPageModule);
    };

    CommissionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_commission_page__WEBPACK_IMPORTED_MODULE_6__["CommissionPage"]]
    })], CommissionPageModule);
    /***/
  },

  /***/
  "./src/app/commission/commission.page.scss":
  /*!*************************************************!*\
    !*** ./src/app/commission/commission.page.scss ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCommissionCommissionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbW1pc3Npb24vY29tbWlzc2lvbi5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/commission/commission.page.ts":
  /*!***********************************************!*\
    !*** ./src/app/commission/commission.page.ts ***!
    \***********************************************/

  /*! exports provided: CommissionPage */

  /***/
  function srcAppCommissionCommissionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionPage", function () {
      return CommissionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _commission_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./commission.service */
    "./src/app/commission/commission.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CommissionPage =
    /*#__PURE__*/
    function () {
      function CommissionPage(fb, commissionService, router) {
        _classCallCheck(this, CommissionPage);

        this.fb = fb;
        this.commissionService = commissionService;
        this.router = router;
        this.withdrawalForm = false;
      }

      _createClass(CommissionPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.commissionForm = this.fb.group({
            amount: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])]
          });
          this.userCode = sessionStorage.getItem('userCode');
          this.getCommissionBalance();
        }
      }, {
        key: "getCommissionBalance",
        value: function getCommissionBalance() {
          var _this = this;

          this.commissionService.getCommissionBalance().subscribe(function (response) {
            _this.commissionBalance = response;
            console.log(response);
          });
        }
      }, {
        key: "getOtp",
        value: function getOtp() {
          this.commissionService.getOtp().subscribe(function (response) {
            console.log(response);
          });
        }
      }, {
        key: "enterWithdrawalAmount",
        value: function enterWithdrawalAmount(form) {
          sessionStorage.setItem('withdrawalAmount', form.value.amount);
          this.getOtp();
          this.router.navigate(['/withdraw-funds']);
        }
      }, {
        key: "openWithdrawalForm",
        value: function openWithdrawalForm() {
          this.withdrawalForm = true;
        }
      }]);

      return CommissionPage;
    }();

    CommissionPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _commission_service__WEBPACK_IMPORTED_MODULE_2__["CommissionService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
      }];
    };

    CommissionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
      selector: 'app-commission',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./commission.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/commission/commission.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./commission.page.scss */
      "./src/app/commission/commission.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _commission_service__WEBPACK_IMPORTED_MODULE_2__["CommissionService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])], CommissionPage);
    /***/
  },

  /***/
  "./src/app/commission/commission.service.ts":
  /*!**************************************************!*\
    !*** ./src/app/commission/commission.service.ts ***!
    \**************************************************/

  /*! exports provided: CommissionService */

  /***/
  function srcAppCommissionCommissionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionService", function () {
      return CommissionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var CommissionService =
    /*#__PURE__*/
    function () {
      function CommissionService(http) {
        _classCallCheck(this, CommissionService);

        this.http = http;
      }

      _createClass(CommissionService, [{
        key: "getCommissionBalance",
        value: function getCommissionBalance() {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/dalexpaddies/balance"));
        }
      }, {
        key: "getOtp",
        value: function getOtp() {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi, "/dalexpaddies/Otp"));
        }
      }]);

      return CommissionService;
    }();

    CommissionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    CommissionService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], CommissionService);
    /***/
  }
}]);
//# sourceMappingURL=commission-commission-module-es5.js.map