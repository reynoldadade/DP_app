function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pending-requests-pending-requests-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pending-requests/pending-requests.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pending-requests/pending-requests.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPendingRequestsPendingRequestsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar [color]=\"'primary'\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Pending Requests</ion-title>\n  </ion-toolbar>\n  <ion-searchbar [color]=\"'light'\" [(ngModel)]=\"searchText\"></ion-searchbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid [fixed]=\"true\">\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n        <ion-card>\n          <ion-card-content>\n            <form [formGroup]=\"dealsForm\" (submit)=\"getActiveDeals(dealsForm)\">\n              <ion-item>\n                <ion-label>Start Date</ion-label>\n                <ion-datetime\n                  placeholder=\"Select Date\"\n                  [formControlName]=\"'startDate'\"\n                  [max]=\"today\"\n                ></ion-datetime>\n              </ion-item>\n              <ion-item>\n                <ion-label>End Date</ion-label>\n                <ion-datetime\n                  placeholder=\"Select Date\"\n                  [formControlName]=\"'endDate'\"\n                ></ion-datetime>\n              </ion-item>\n              <ion-button\n                [expand]=\"'full'\"\n                type=\"submit\"\n                [disabled]=\"dealsForm.invalid\"\n              >\n                Search Deals<ion-spinner *ngIf=\"spinner\"></ion-spinner>\n              </ion-button>\n            </form>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n    <div *ngIf=\"found\">\n      <ion-row>\n        <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n          <ion-list>\n            <ion-item\n              *ngFor=\"let deal of deals| idFilter:searchText;\"\n              (click)=\"viewTransaction(deal)\"\n            >\n              <ion-label class=\"eligibility\">\n                <h2>{{deal.ClientName}} [{{deal.ClientRefId}}]</h2>\n                <h2>\n                  Amount:\n                  <ion-text [color]=\"'primary'\">{{deal.GrossAmount}}</ion-text>|\n                  Status:\n                  <ion-text [color]=\"'primary'\"\n                    >{{deal.TransactionStatus}}</ion-text\n                  >\n                </h2>\n                <h2>{{deal.LoanType}}</h2>\n                <h2>{{deal.Tenor}} months</h2>\n                <h2>{{deal.StatusDate| date: 'medium'}}</h2>\n              </ion-label>\n            </ion-item>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n    </div>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/pending-requests/pending-requests.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pending-requests/pending-requests.module.ts ***!
    \*************************************************************/

  /*! exports provided: PendingRequestsPageModule */

  /***/
  function srcAppPendingRequestsPendingRequestsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PendingRequestsPageModule", function () {
      return PendingRequestsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _pending_requests_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./pending-requests.page */
    "./src/app/pending-requests/pending-requests.page.ts");
    /* harmony import */


    var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../pipes/pipes/pipes.module */
    "./src/app/pipes/pipes/pipes.module.ts");

    var routes = [{
      path: '',
      component: _pending_requests_page__WEBPACK_IMPORTED_MODULE_6__["PendingRequestsPage"]
    }];

    var PendingRequestsPageModule = function PendingRequestsPageModule() {
      _classCallCheck(this, PendingRequestsPageModule);
    };

    PendingRequestsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__["PipesModule"]],
      declarations: [_pending_requests_page__WEBPACK_IMPORTED_MODULE_6__["PendingRequestsPage"]]
    })], PendingRequestsPageModule);
    /***/
  },

  /***/
  "./src/app/pending-requests/pending-requests.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pending-requests/pending-requests.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPendingRequestsPendingRequestsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BlbmRpbmctcmVxdWVzdHMvcGVuZGluZy1yZXF1ZXN0cy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pending-requests/pending-requests.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pending-requests/pending-requests.page.ts ***!
    \***********************************************************/

  /*! exports provided: PendingRequestsPage */

  /***/
  function srcAppPendingRequestsPendingRequestsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PendingRequestsPage", function () {
      return PendingRequestsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../shared/shared.service */
    "./src/app/shared/shared.service.ts");
    /* harmony import */


    var _pending_requests_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./pending-requests.service */
    "./src/app/pending-requests/pending-requests.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var PendingRequestsPage =
    /*#__PURE__*/
    function () {
      function PendingRequestsPage(fb, sharedService, pendingRequestService, router) {
        _classCallCheck(this, PendingRequestsPage);

        this.fb = fb;
        this.sharedService = sharedService;
        this.pendingRequestService = pendingRequestService;
        this.router = router;
        this.searchText = '';
        this.today = new Date().toISOString();
        this.found = false;
        this.spinner = false;
      }

      _createClass(PendingRequestsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.user = sessionStorage.getItem('userCode');

          if (!this.user) {
            this.user = '56-0001-00004';
          }

          if (this.user) {
            this.dealsForm = this.fb.group({
              startDate: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
              endDate: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            });
          }
        }
      }, {
        key: "getActiveDeals",
        value: function getActiveDeals(form) {
          var _this = this;

          this.found = false;
          this.spinner = true;
          this.pendingRequestService.getTransactions(form.value).subscribe(function (response) {
            _this.spinner = false;
            console.log(response);

            if (response.length < 1) {
              _this.sharedService.presentToast('No deals found during this period');
            } else {
              _this.found = true;
              _this.deals = response.reverse(); // console.log(deals);
            }
          }, function () {
            _this.spinner = false;

            _this.sharedService.presentToast('Network Failure');
          });
        }
      }, {
        key: "viewTransaction",
        value: function viewTransaction(item) {
          this.sharedService.saveItem('loanDetails', item);
          this.router.navigate(['view-loan']);
        }
      }]);

      return PendingRequestsPage;
    }();

    PendingRequestsPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"]
      }, {
        type: _pending_requests_service__WEBPACK_IMPORTED_MODULE_4__["PendingRequestsService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    PendingRequestsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-pending-requests',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./pending-requests.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pending-requests/pending-requests.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./pending-requests.page.scss */
      "./src/app/pending-requests/pending-requests.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"], _pending_requests_service__WEBPACK_IMPORTED_MODULE_4__["PendingRequestsService"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])], PendingRequestsPage);
    /***/
  },

  /***/
  "./src/app/pending-requests/pending-requests.service.ts":
  /*!**************************************************************!*\
    !*** ./src/app/pending-requests/pending-requests.service.ts ***!
    \**************************************************************/

  /*! exports provided: PendingRequestsService */

  /***/
  function srcAppPendingRequestsPendingRequestsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PendingRequestsService", function () {
      return PendingRequestsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../environments/environment */
    "./src/environments/environment.ts");

    var PendingRequestsService =
    /*#__PURE__*/
    function () {
      function PendingRequestsService(http) {
        _classCallCheck(this, PendingRequestsService);

        this.http = http;
      }

      _createClass(PendingRequestsService, [{
        key: "getTransactions",
        value: function getTransactions(data) {
          var httpParams = {
            fromObject: data
          };
          var options = {
            params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"](httpParams)
          };
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi, "/dalexpaddies/PendingDeals"), options);
        }
      }]);

      return PendingRequestsService;
    }();

    PendingRequestsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    PendingRequestsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], PendingRequestsService);
    /***/
  }
}]);
//# sourceMappingURL=pending-requests-pending-requests-module-es5.js.map