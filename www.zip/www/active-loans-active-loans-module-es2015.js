(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["active-loans-active-loans-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/active-loans/active-loans.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/active-loans/active-loans.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [color]=\"'primary'\">\n        <ion-buttons slot=\"start\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title class=\"ion-text-center\">Credit Check</ion-title>\n    </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <form\n                    [formGroup]=\"activeLoansForm\"\n                    (submit)=\"getActiveLoans(activeLoansForm)\"\n                >\n                    <ion-item>\n                        <ion-label [position]=\"'stacked'\"\n                            >Enter Staff ID</ion-label\n                        >\n                        <ion-input formControlName=\"id\"></ion-input>\n                    </ion-item>\n                    <ion-button\n                        type=\"submit\"\n                        [disabled]=\"activeLoansForm.invalid\"\n                        >Credit Check <ion-spinner *ngIf=\"spin\"></ion-spinner\n                    ></ion-button>\n                </form>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <ion-list>\n                    <ion-item *ngIf=\"message\">\n                        <ion-label class=\"ion-text-center eligibility\"\n                            >CLIENT IS {{eligibility?.Status}}</ion-label\n                        >\n                    </ion-item>\n                    <div *ngIf=\"eligible\">\n                        <ion-item>\n                            <ion-label class=\"eligibility\"\n                                >Staff Name:\n                                {{eligibility?.FullName}}</ion-label\n                            >\n                        </ion-item>\n                        <ion-item>\n                            <ion-label class=\" eligibility\"\n                                >Staff Id:\n                                {{eligibility?.EmployeeID}}</ion-label\n                            >\n                        </ion-item>\n                        <ion-item>\n                            <ion-label class=\"eligibility\"\n                                >Age: {{eligibility?.Age}}</ion-label\n                            >\n                        </ion-item>\n                        <ion-item>\n                            <ion-label class=\"eligibility\"\n                                >Tenor: {{eligibility?.Tenor}}</ion-label\n                            >\n                        </ion-item>\n                    </div>\n                </ion-list>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <ion-list>\n                    <ion-item *ngFor=\"let activeLoan of activeLoans\">\n                        <!-- <ion-checkbox\n                            slot=\"start\"\n                            (click)=\"getLoan(activeLoan, $event); checkIfLoanIsReplacementAndChangeText();\"\n                        ></ion-checkbox> -->\n                        <ion-label>\n                            <h2>\n                                {{activeLoan?.Employee_Name}} |\n                                {{activeLoan?.Employee_Id}}\n                            </h2>\n                            <h2>Loan ID: {{activeLoan?.Loan_No}}</h2>\n                            <h2>\n                                Replacement Balance:\n                                {{activeLoan?.ReplacementAmountDue}}\n                            </h2>\n                            <h2>\n                                Outright Balance:\n                                {{activeLoan?.OutrightAmountDue}}\n                            </h2>\n                        </ion-label>\n                    </ion-item>\n                </ion-list>\n            </ion-col>\n        </ion-row>\n        <ion-row *ngIf=\"eligible && activeLoans\">\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\" [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <ion-button expand=\"block\" (click)=\"moveToLoanProcessPage()\"\n                    >{{loanButtonText}}</ion-button\n                >\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/active-loans/active-loans.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/active-loans/active-loans.module.ts ***!
  \*****************************************************/
/*! exports provided: ActiveLoansPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveLoansPageModule", function() { return ActiveLoansPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _active_loans_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./active-loans.page */ "./src/app/active-loans/active-loans.page.ts");







const routes = [
    {
        path: '',
        component: _active_loans_page__WEBPACK_IMPORTED_MODULE_6__["ActiveLoansPage"],
    },
];
let ActiveLoansPageModule = class ActiveLoansPageModule {
};
ActiveLoansPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
        ],
        declarations: [_active_loans_page__WEBPACK_IMPORTED_MODULE_6__["ActiveLoansPage"]],
    })
], ActiveLoansPageModule);



/***/ }),

/***/ "./src/app/active-loans/active-loans.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/active-loans/active-loans.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FjdGl2ZS1sb2Fucy9hY3RpdmUtbG9hbnMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/active-loans/active-loans.page.ts":
/*!***************************************************!*\
  !*** ./src/app/active-loans/active-loans.page.ts ***!
  \***************************************************/
/*! exports provided: ActiveLoansPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveLoansPage", function() { return ActiveLoansPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _shared_shared_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../shared/shared.service */ "./src/app/shared/shared.service.ts");
/* harmony import */ var _active_loans_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./active-loans.service */ "./src/app/active-loans/active-loans.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let ActiveLoansPage = class ActiveLoansPage {
    constructor(fb, activeloansService, shared, router) {
        this.fb = fb;
        this.activeloansService = activeloansService;
        this.shared = shared;
        this.router = router;
        this.spin = false;
        this.loanButtonText = 'Post New Loan';
        this.replacementLoanArray = [];
    }
    ngOnInit() {
        this.activeLoans = [];
        this.eligibility = null;
        this.eligible = false;
        this.activeLoansForm = this.fb.group({
            id: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
        });
    }
    getActiveLoans(form) {
        sessionStorage.setItem('clientId', form.value.id);
        this.creditCheck(form.value);
        // this.callActiveLoansService(form.value);
    }
    callActiveLoansService(data) {
        // this.spin = true;
        this.activeloansService.getActiveLoans(data).subscribe(response => {
            const loanArray = JSON.parse(response.Data);
            console.log(loanArray);
            if (loanArray.length === 0) {
                // console.log('id not found');
                this.shared.presentToast('Loan not found for this ID');
            }
            this.activeLoans = loanArray;
            sessionStorage.setItem('activeloans', response.Data);
            this.spin = false;
            this.loanButtonText = 'Post a new/replacement loan';
            // console.log(response.Data);
        }, () => {
            this.shared.presentToast('Server Error');
            this.spin = false;
        });
    }
    getLoan(loan, e) {
        const index = this.replacementLoanArray.indexOf(loan);
        if (!e.target.checked) {
            this.replacementLoanArray.push(loan);
        }
        else {
            this.replacementLoanArray.splice(index, 1);
        }
        console.log(this.replacementLoanArray);
    }
    checkIfLoanIsReplacementAndChangeText() {
        if (this.replacementLoanArray.length > 0) {
            this.loanButtonText = 'Post a replacement loan';
        }
        else {
            this.loanButtonText = 'Post a new loan';
        }
    }
    moveToLoanProcessPage() {
        sessionStorage.setItem('loansToReplace', JSON.stringify(this.replacementLoanArray));
        this.router.navigate(['post-loan']);
    }
    creditCheck(data) {
        this.spin = true;
        this.activeLoans = null;
        this.activeloansService.creditCheck(data).subscribe(response => {
            this.message = true;
            if (response.Status === 'true') {
                this.eligibility = JSON.parse(response.Data);
                if (this.eligibility.Status === 'ELIGIBLE') {
                    this.eligible = true;
                    sessionStorage.setItem('eligibilityData', response.Data);
                    this.callActiveLoansService(data);
                }
                else {
                    this.spin = false;
                }
            }
            else {
                this.shared.presentToast('Client Not Found');
                this.spin = false;
            }
            // this.spin = false;
        }, error => {
            this.shared.presentToast('Network Error');
            this.spin = false;
        });
    }
};
ActiveLoansPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _active_loans_service__WEBPACK_IMPORTED_MODULE_2__["ActiveLoansService"] },
    { type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
ActiveLoansPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-active-loans',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./active-loans.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/active-loans/active-loans.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./active-loans.page.scss */ "./src/app/active-loans/active-loans.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
        _active_loans_service__WEBPACK_IMPORTED_MODULE_2__["ActiveLoansService"],
        _shared_shared_service__WEBPACK_IMPORTED_MODULE_1__["SharedService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], ActiveLoansPage);



/***/ }),

/***/ "./src/app/active-loans/active-loans.service.ts":
/*!******************************************************!*\
  !*** ./src/app/active-loans/active-loans.service.ts ***!
  \******************************************************/
/*! exports provided: ActiveLoansService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActiveLoansService", function() { return ActiveLoansService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");




let ActiveLoansService = class ActiveLoansService {
    constructor(http) {
        this.http = http;
    }
    getActiveLoans(data) {
        const httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('id', data.id.toUpperCase());
        const options = { params: httpParams };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/getNavStaffLoansBulk`, null, options);
    }
    creditCheck(data) {
        const httpParams = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().set('staffId', data.id.toUpperCase());
        const options = { params: httpParams };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].filmsApi}/mobile/creditcheck`, null, options);
    }
};
ActiveLoansService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
ActiveLoansService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], ActiveLoansService);



/***/ })

}]);
//# sourceMappingURL=active-loans-active-loans-module-es2015.js.map