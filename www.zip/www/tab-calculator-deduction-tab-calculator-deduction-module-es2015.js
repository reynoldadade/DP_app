(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-calculator-deduction-tab-calculator-deduction-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-deduction/tab-calculator-deduction.page.html":
/*!*******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-deduction/tab-calculator-deduction.page.html ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid [fixed]=\"true\">\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n        <ion-card>\n          <ion-card-header class=\"ion-text-center\" [color]=\"'primary'\">Calculate Deduction</ion-card-header>\n          <ion-card-content>\n            <form [formGroup]=\"deductionCalculatorForm\" (submit)=\"calculateDeduction(deductionCalculatorForm)\">\n              <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                  Amount\n                </ion-label>\n                <ion-input type=\"number\" [formControlName]=\"'amount'\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                  Tenor\n                </ion-label>\n                <ion-select [interface]=\"'action-sheet'\" [formControlName]=\"'tenor'\">\n                  <ion-select-option *ngFor=\"let loanTenor of loanTenors\" [value]=\"loanTenor\">\n                    {{loanTenor}}\n                  </ion-select-option>\n                </ion-select>\n              </ion-item>\n              <ion-button [expand]=\"'block'\" type=\"submit\">Calculate</ion-button>\n              <ion-item class=\"ion-padding\">\n                <ion-label>Deduction</ion-label>\n                {{deduction}}\n              </ion-item>\n            </form>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./src/app/tab-calculator-deduction/tab-calculator-deduction.module.ts":
/*!*****************************************************************************!*\
  !*** ./src/app/tab-calculator-deduction/tab-calculator-deduction.module.ts ***!
  \*****************************************************************************/
/*! exports provided: TabCalculatorDeductionPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabCalculatorDeductionPageModule", function() { return TabCalculatorDeductionPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _tab_calculator_deduction_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab-calculator-deduction.page */ "./src/app/tab-calculator-deduction/tab-calculator-deduction.page.ts");







const routes = [
    {
        path: '',
        component: _tab_calculator_deduction_page__WEBPACK_IMPORTED_MODULE_6__["TabCalculatorDeductionPage"]
    }
];
let TabCalculatorDeductionPageModule = class TabCalculatorDeductionPageModule {
};
TabCalculatorDeductionPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_tab_calculator_deduction_page__WEBPACK_IMPORTED_MODULE_6__["TabCalculatorDeductionPage"]]
    })
], TabCalculatorDeductionPageModule);



/***/ }),

/***/ "./src/app/tab-calculator-deduction/tab-calculator-deduction.page.scss":
/*!*****************************************************************************!*\
  !*** ./src/app/tab-calculator-deduction/tab-calculator-deduction.page.scss ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYi1jYWxjdWxhdG9yLWRlZHVjdGlvbi90YWItY2FsY3VsYXRvci1kZWR1Y3Rpb24ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/tab-calculator-deduction/tab-calculator-deduction.page.ts":
/*!***************************************************************************!*\
  !*** ./src/app/tab-calculator-deduction/tab-calculator-deduction.page.ts ***!
  \***************************************************************************/
/*! exports provided: TabCalculatorDeductionPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabCalculatorDeductionPage", function() { return TabCalculatorDeductionPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../loan-calculator/loan-calculator.service */ "./src/app/loan-calculator/loan-calculator.service.ts");
/* harmony import */ var _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.service */ "./src/app/shared/shared.service.ts");





let TabCalculatorDeductionPage = class TabCalculatorDeductionPage {
    constructor(fb, loanCalculatorService, sharedService) {
        this.fb = fb;
        this.loanCalculatorService = loanCalculatorService;
        this.sharedService = sharedService;
        this.loanTenors = [3, 6, 12, 18, 24, 36, 48, 54];
    }
    ngOnInit() {
        this.deductionCalculatorForm = this.fb.group({
            amount: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0.01), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            tenor: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])]
        });
    }
    calculateDeduction(form) {
        this.loanCalculatorService.getRateScheduleDeduction(form.value).subscribe((response) => {
            // console.log(response);
            // form.reset();
            const deduction = JSON.parse(response.Data);
            this.deduction = parseFloat(deduction).toFixed(2);
            // console.log(typeof this.deduction);
        });
    }
};
TabCalculatorDeductionPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__["LoanCalculatorService"] },
    { type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"] }
];
TabCalculatorDeductionPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab-calculator-deduction',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./tab-calculator-deduction.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-deduction/tab-calculator-deduction.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./tab-calculator-deduction.page.scss */ "./src/app/tab-calculator-deduction/tab-calculator-deduction.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__["LoanCalculatorService"], _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]])
], TabCalculatorDeductionPage);



/***/ })

}]);
//# sourceMappingURL=tab-calculator-deduction-tab-calculator-deduction-module-es2015.js.map