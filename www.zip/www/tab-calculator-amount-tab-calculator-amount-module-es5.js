function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab-calculator-amount-tab-calculator-amount-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-amount/tab-calculator-amount.page.html":
  /*!*************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-amount/tab-calculator-amount.page.html ***!
    \*************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppTabCalculatorAmountTabCalculatorAmountPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <!--<ion-title>Total Amount</ion-title>-->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n        <ion-card>\n          <ion-card-header class=\"ion-text-center\" [color]=\"'primary'\">Calculate Loan Amount</ion-card-header>\n          <ion-card-content>\n            <form [formGroup]=\"amountCalculatorForm\" (submit)=\"calculateAmount(amountCalculatorForm)\">\n              <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                  Deduction\n                </ion-label>\n                <ion-input type=\"number\" [formControlName]=\"'deduction'\"></ion-input>\n              </ion-item>\n              <ion-item>\n                <ion-label [position]=\"'stacked'\">\n                  Tenor\n                </ion-label>\n                <ion-select [interface]=\"'action-sheet'\" [formControlName]=\"'tenor'\">\n                  <ion-select-option *ngFor=\"let loanTenor of loanTenors\" [value]=\"loanTenor\">\n                    {{loanTenor}}\n                  </ion-select-option>\n                </ion-select>\n              </ion-item>\n              <ion-button [expand]=\"'block'\" type=\"submit\">Calculate</ion-button>\n              <ion-item class=\"ion-padding\">\n                <ion-label>Amount</ion-label>\n                {{amount}}\n              </ion-item>\n            </form>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/tab-calculator-amount/tab-calculator-amount.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/tab-calculator-amount/tab-calculator-amount.module.ts ***!
    \***********************************************************************/

  /*! exports provided: TabCalculatorAmountPageModule */

  /***/
  function srcAppTabCalculatorAmountTabCalculatorAmountModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabCalculatorAmountPageModule", function () {
      return TabCalculatorAmountPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _tab_calculator_amount_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tab-calculator-amount.page */
    "./src/app/tab-calculator-amount/tab-calculator-amount.page.ts");

    var routes = [{
      path: '',
      component: _tab_calculator_amount_page__WEBPACK_IMPORTED_MODULE_6__["TabCalculatorAmountPage"]
    }];

    var TabCalculatorAmountPageModule = function TabCalculatorAmountPageModule() {
      _classCallCheck(this, TabCalculatorAmountPageModule);
    };

    TabCalculatorAmountPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_tab_calculator_amount_page__WEBPACK_IMPORTED_MODULE_6__["TabCalculatorAmountPage"]]
    })], TabCalculatorAmountPageModule);
    /***/
  },

  /***/
  "./src/app/tab-calculator-amount/tab-calculator-amount.page.scss":
  /*!***********************************************************************!*\
    !*** ./src/app/tab-calculator-amount/tab-calculator-amount.page.scss ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppTabCalculatorAmountTabCalculatorAmountPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RhYi1jYWxjdWxhdG9yLWFtb3VudC90YWItY2FsY3VsYXRvci1hbW91bnQucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/tab-calculator-amount/tab-calculator-amount.page.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/tab-calculator-amount/tab-calculator-amount.page.ts ***!
    \*********************************************************************/

  /*! exports provided: TabCalculatorAmountPage */

  /***/
  function srcAppTabCalculatorAmountTabCalculatorAmountPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabCalculatorAmountPage", function () {
      return TabCalculatorAmountPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../loan-calculator/loan-calculator.service */
    "./src/app/loan-calculator/loan-calculator.service.ts");
    /* harmony import */


    var _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../shared/shared.service */
    "./src/app/shared/shared.service.ts");

    var TabCalculatorAmountPage =
    /*#__PURE__*/
    function () {
      function TabCalculatorAmountPage(fb, loanCalculatorService, sharedService) {
        _classCallCheck(this, TabCalculatorAmountPage);

        this.fb = fb;
        this.loanCalculatorService = loanCalculatorService;
        this.sharedService = sharedService;
        this.amount = 0;
        this.loanTenors = [3, 6, 12, 18, 24, 36, 48, 54];
      }

      _createClass(TabCalculatorAmountPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.amountCalculatorForm = this.fb.group({
            deduction: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(0.01), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            tenor: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].min(1), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])]
          });
        }
      }, {
        key: "calculateAmount",
        value: function calculateAmount(form) {
          var _this = this;

          this.loanCalculatorService.getRateScheduleAmount(form.value).subscribe(function (response) {
            // console.log(response);
            // form.reset();
            _this.amount = response.Data;
          });
        }
      }]);

      return TabCalculatorAmountPage;
    }();

    TabCalculatorAmountPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__["LoanCalculatorService"]
      }, {
        type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]
      }];
    };

    TabCalculatorAmountPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tab-calculator-amount',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tab-calculator-amount.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/tab-calculator-amount/tab-calculator-amount.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tab-calculator-amount.page.scss */
      "./src/app/tab-calculator-amount/tab-calculator-amount.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _loan_calculator_loan_calculator_service__WEBPACK_IMPORTED_MODULE_3__["LoanCalculatorService"], _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]])], TabCalculatorAmountPage);
    /***/
  }
}]);
//# sourceMappingURL=tab-calculator-amount-tab-calculator-amount-module-es5.js.map