function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["landing-landing-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/landing/landing.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/landing/landing.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLandingLandingPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar [color]=\"'primary'\">\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title class=\"ion-text-center\">Dashboard</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col>\n        <div style=\"--aspect-ratio: 16/9;\">\n          <iframe\n            id=\"biFrame\"\n            allowfullscreen\n            src=\"https://app.powerbi.com/view?r=eyJrIjoiNTg4NjE4YzAtN2U0ZC00OWMzLTg1NDgtZTRlZjQ4MTliNzg1IiwidCI6IjA1OGEyNGJlLTY1MjItNGY2Yi1iZjdmLWQ2YzNkYzMwZmI5NiIsImMiOjl9\"\n          >\n          </iframe>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/landing/landing.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/landing/landing.module.ts ***!
    \*******************************************/

  /*! exports provided: LandingPageModule */

  /***/
  function srcAppLandingLandingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LandingPageModule", function () {
      return LandingPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _landing_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./landing.page */
    "./src/app/landing/landing.page.ts");

    var routes = [{
      path: '',
      component: _landing_page__WEBPACK_IMPORTED_MODULE_6__["LandingPage"]
    }];

    var LandingPageModule = function LandingPageModule() {
      _classCallCheck(this, LandingPageModule);
    };

    LandingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_landing_page__WEBPACK_IMPORTED_MODULE_6__["LandingPage"]]
    })], LandingPageModule);
    /***/
  },

  /***/
  "./src/app/landing/landing.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/landing/landing.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppLandingLandingPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "[style*=\"--aspect-ratio\"] > :first-child {\n  width: 100%;\n}\n\n[style*=\"--aspect-ratio\"] > img {\n  height: auto;\n}\n\n@supports (--custom: property) {\n  [style*=\"--aspect-ratio\"] {\n    position: relative;\n  }\n\n  [style*=\"--aspect-ratio\"]::before {\n    content: \"\";\n    display: block;\n    padding-bottom: calc(100% / (var(--aspect-ratio)));\n  }\n\n  [style*=\"--aspect-ratio\"] > :first-child {\n    position: absolute;\n    top: 0;\n    left: 0;\n    height: 100%;\n  }\n}\n\n@media screen and (min-width: 320px) and (max-width: 767px) and (orientation: landscape) {\n  html {\n    -webkit-transform: rotate(-90deg);\n            transform: rotate(-90deg);\n    -webkit-transform-origin: left top;\n            transform-origin: left top;\n    width: 100vh;\n    overflow-x: hidden;\n    position: absolute;\n    top: 100%;\n    left: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbGFuZGluZy9FOlxcREFMRVggQ09ERVxcZHBBcHAyL3NyY1xcYXBwXFxsYW5kaW5nXFxsYW5kaW5nLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbGFuZGluZy9sYW5kaW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7QUNDRjs7QURDQTtFQUNFLFlBQUE7QUNFRjs7QURDQTtFQUNFO0lBQ0Usa0JBQUE7RUNFRjs7RURBQTtJQUNFLFdBQUE7SUFDQSxjQUFBO0lBQ0Esa0RBQUE7RUNHRjs7RUREQTtJQUNFLGtCQUFBO0lBQ0EsTUFBQTtJQUNBLE9BQUE7SUFDQSxZQUFBO0VDSUY7QUFDRjs7QUREQTtFQUNFO0lBQ0UsaUNBQUE7WUFBQSx5QkFBQTtJQUNBLGtDQUFBO1lBQUEsMEJBQUE7SUFDQSxZQUFBO0lBQ0Esa0JBQUE7SUFDQSxrQkFBQTtJQUNBLFNBQUE7SUFDQSxPQUFBO0VDR0Y7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2xhbmRpbmcvbGFuZGluZy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJbc3R5bGUqPVwiLS1hc3BlY3QtcmF0aW9cIl0gPiA6Zmlyc3QtY2hpbGQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcbltzdHlsZSo9XCItLWFzcGVjdC1yYXRpb1wiXSA+IGltZyB7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG5Ac3VwcG9ydHMgKC0tY3VzdG9tOnByb3BlcnR5KSB7XHJcbiAgW3N0eWxlKj1cIi0tYXNwZWN0LXJhdGlvXCJdIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB9XHJcbiAgW3N0eWxlKj1cIi0tYXNwZWN0LXJhdGlvXCJdOjpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcIjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcGFkZGluZy1ib3R0b206IGNhbGMoMTAwJSAvICh2YXIoLS1hc3BlY3QtcmF0aW8pKSk7XHJcbiAgfVxyXG4gIFtzdHlsZSo9XCItLWFzcGVjdC1yYXRpb1wiXSA+IDpmaXJzdC1jaGlsZCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMzIwcHgpIGFuZCAobWF4LXdpZHRoOiA3NjdweCkgYW5kIChvcmllbnRhdGlvbjogbGFuZHNjYXBlKSB7XHJcbiAgaHRtbCB7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtOTBkZWcpO1xyXG4gICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdCB0b3A7XHJcbiAgICB3aWR0aDogMTAwdmg7XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwMCU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gIH1cclxufSIsIltzdHlsZSo9XCItLWFzcGVjdC1yYXRpb1wiXSA+IDpmaXJzdC1jaGlsZCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG5bc3R5bGUqPVwiLS1hc3BlY3QtcmF0aW9cIl0gPiBpbWcge1xuICBoZWlnaHQ6IGF1dG87XG59XG5cbkBzdXBwb3J0cyAoLS1jdXN0b206IHByb3BlcnR5KSB7XG4gIFtzdHlsZSo9XCItLWFzcGVjdC1yYXRpb1wiXSB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB9XG5cbiAgW3N0eWxlKj1cIi0tYXNwZWN0LXJhdGlvXCJdOjpiZWZvcmUge1xuICAgIGNvbnRlbnQ6IFwiXCI7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgcGFkZGluZy1ib3R0b206IGNhbGMoMTAwJSAvICh2YXIoLS1hc3BlY3QtcmF0aW8pKSk7XG4gIH1cblxuICBbc3R5bGUqPVwiLS1hc3BlY3QtcmF0aW9cIl0gPiA6Zmlyc3QtY2hpbGQge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbGVmdDogMDtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gIH1cbn1cbkBtZWRpYSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDMyMHB4KSBhbmQgKG1heC13aWR0aDogNzY3cHgpIGFuZCAob3JpZW50YXRpb246IGxhbmRzY2FwZSkge1xuICBodG1sIHtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtOTBkZWcpO1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IGxlZnQgdG9wO1xuICAgIHdpZHRoOiAxMDB2aDtcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogMTAwJTtcbiAgICBsZWZ0OiAwO1xuICB9XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/landing/landing.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/landing/landing.page.ts ***!
    \*****************************************/

  /*! exports provided: LandingPage */

  /***/
  function srcAppLandingLandingPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LandingPage", function () {
      return LandingPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var LandingPage =
    /*#__PURE__*/
    function () {
      function LandingPage(menuCtrl) {
        _classCallCheck(this, LandingPage);

        this.menuCtrl = menuCtrl;
        this.today = new Date();
      }

      _createClass(LandingPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {// const width = window.screen.availWidth;
          // console.log(width);
          // console.log(screen.orientation.type, 'type');
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.menuCtrl.enable(true);
        }
      }]);

      return LandingPage;
    }();

    LandingPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]
      }];
    };

    LandingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-landing',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./landing.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/landing/landing.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./landing.page.scss */
      "./src/app/landing/landing.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"]])], LandingPage);
    /***/
  }
}]);
//# sourceMappingURL=landing-landing-module-es5.js.map