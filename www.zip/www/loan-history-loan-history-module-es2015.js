(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loan-history-loan-history-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/loan-history/loan-history.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/loan-history/loan-history.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar [color]=\"'primary'\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Loan History</ion-title>\n  </ion-toolbar>\n  <ion-searchbar [color]=\"'light'\" [(ngModel)]=\"searchText\"></ion-searchbar>\n</ion-header>\n\n<ion-content>\n<ion-grid [fixed]=\"true\">\n  <ion-row>\n    <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n      <ion-card>\n        <ion-card-content>\n          <form [formGroup]=\"dealsForm\" (submit)=\"getPaidDeals(dealsForm)\">\n            <ion-item>\n              <ion-label>Start Date</ion-label>\n              <ion-datetime  placeholder=\"Select Date\" [formControlName]=\"'start'\" [max]=\"today\"></ion-datetime>\n            </ion-item>\n            <ion-item>\n              <ion-label>End Date</ion-label>\n              <ion-datetime  placeholder=\"Select Date\" [formControlName]=\"'end'\" ></ion-datetime>\n            </ion-item>\n            <ion-button [expand]=\"'full'\" type=\"submit\" [disabled]=\"dealsForm.invalid\">\n              Search Deals<ion-spinner *ngIf=\"spinner\"></ion-spinner>\n            </ion-button>\n          </form>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n  </ion-row>\n  <div *ngIf=\"found\">\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n        <ion-card>\n          <ion-card-header>Commission Summary</ion-card-header>\n          <ion-card-content>\n            <ion-item>\n              Total Commission: GH¢{{loanSummary?.TotalCommission}}\n            </ion-item>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n        <ion-list>\n          <ion-item *ngFor=\"let deal of deals|idFilter:searchText\">\n            <ion-label class=\"eligibility\">\n              <h2>{{deal.ClientName}} [{{deal.ClientRefId}}]</h2>\n              <h2>Amount: <ion-text [color]=\"'primary'\">{{deal.GrossAmount}}</ion-text></h2>\n              <h2> Commission: <ion-text [color]=\"'primary'\">{{deal.Commission}}</ion-text></h2>\n              <h2>{{deal.LoanType}}| {{deal.Tenor}} months</h2>\n              <h2>Paid on: {{deal.StatusDate| date: 'medium'}}</h2>\n            </ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n  </div>\n</ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/loan-history/loan-history.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/loan-history/loan-history.module.ts ***!
  \*****************************************************/
/*! exports provided: LoanHistoryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanHistoryPageModule", function() { return LoanHistoryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _loan_history_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./loan-history.page */ "./src/app/loan-history/loan-history.page.ts");
/* harmony import */ var _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../pipes/pipes/pipes.module */ "./src/app/pipes/pipes/pipes.module.ts");








const routes = [
    {
        path: '',
        component: _loan_history_page__WEBPACK_IMPORTED_MODULE_6__["LoanHistoryPage"]
    }
];
let LoanHistoryPageModule = class LoanHistoryPageModule {
};
LoanHistoryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
            _pipes_pipes_pipes_module__WEBPACK_IMPORTED_MODULE_7__["PipesModule"]
        ],
        declarations: [_loan_history_page__WEBPACK_IMPORTED_MODULE_6__["LoanHistoryPage"]]
    })
], LoanHistoryPageModule);



/***/ }),

/***/ "./src/app/loan-history/loan-history.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/loan-history/loan-history.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvYW4taGlzdG9yeS9sb2FuLWhpc3RvcnkucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/loan-history/loan-history.page.ts":
/*!***************************************************!*\
  !*** ./src/app/loan-history/loan-history.page.ts ***!
  \***************************************************/
/*! exports provided: LoanHistoryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanHistoryPage", function() { return LoanHistoryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/shared.service */ "./src/app/shared/shared.service.ts");
/* harmony import */ var _loan_history_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./loan-history.service */ "./src/app/loan-history/loan-history.service.ts");





let LoanHistoryPage = class LoanHistoryPage {
    constructor(fb, sharedService, loanHistoryService) {
        this.fb = fb;
        this.sharedService = sharedService;
        this.loanHistoryService = loanHistoryService;
        this.searchText = '';
        this.today = new Date().toISOString();
        this.loanSummary = {
            TotalCommission: 0,
            TotalLoans: 0,
            TotalOverider: 0
        };
        this.found = false;
        this.spinner = false;
    }
    ngOnInit() {
        this.user = sessionStorage.getItem('userCode');
        if (!this.user) {
            this.user = '56-0001-00004';
        }
        if (this.user) {
            this.dealsForm = this.fb.group({
                start: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
                end: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
                type: ['DP'],
                usercode: [this.user]
            });
        }
    }
    getPaidDeals(form) {
        this.found = false;
        this.spinner = true;
        this.loanHistoryService.getDeals(form.value).subscribe((response) => {
            this.spinner = false;
            if (response.Status === 'fail') {
                this.sharedService.presentToast(response.Message);
            }
            else {
                this.found = true;
                const deals = JSON.parse(response.Data);
                this.deals = deals.ActiveLoans;
                this.loanSummary = deals.LoanSummary;
                console.log(deals);
            }
        }, () => {
            this.spinner = false;
            this.sharedService.presentToast('Network Failure');
        });
    }
};
LoanHistoryPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"] },
    { type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"] },
    { type: _loan_history_service__WEBPACK_IMPORTED_MODULE_4__["LoanHistoryService"] }
];
LoanHistoryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-loan-history',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./loan-history.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/loan-history/loan-history.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./loan-history.page.scss */ "./src/app/loan-history/loan-history.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _shared_shared_service__WEBPACK_IMPORTED_MODULE_3__["SharedService"], _loan_history_service__WEBPACK_IMPORTED_MODULE_4__["LoanHistoryService"]])
], LoanHistoryPage);



/***/ }),

/***/ "./src/app/loan-history/loan-history.service.ts":
/*!******************************************************!*\
  !*** ./src/app/loan-history/loan-history.service.ts ***!
  \******************************************************/
/*! exports provided: LoanHistoryService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoanHistoryService", function() { return LoanHistoryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");




let LoanHistoryService = class LoanHistoryService {
    constructor(http) {
        this.http = http;
    }
    getDeals(data) {
        const httpParams = { fromObject: data };
        const options = { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"](httpParams) };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi}/mobile/getallactiverequests`, null, options);
    }
};
LoanHistoryService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
LoanHistoryService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], LoanHistoryService);



/***/ })

}]);
//# sourceMappingURL=loan-history-loan-history-module-es2015.js.map