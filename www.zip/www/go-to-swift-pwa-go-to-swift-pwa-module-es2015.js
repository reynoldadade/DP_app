(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["go-to-swift-pwa-go-to-swift-pwa-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/go-to-swift-pwa/go-to-swift-pwa.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/go-to-swift-pwa/go-to-swift-pwa.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [color]=\"'primary'\">\n        <ion-buttons slot=\"start\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n            <ion-menu-button></ion-menu-button>\n        </ion-buttons>\n        <ion-title>Go to Swift App</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <ion-button\n                    expand=\"block\"\n                    [href]=\"'https://app.dalexswift.com/signin'\"\n                    >Go to Swift App</ion-button\n                >\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/go-to-swift-pwa/go-to-swift-pwa.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/go-to-swift-pwa/go-to-swift-pwa.module.ts ***!
  \***********************************************************/
/*! exports provided: GoToSwiftPwaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoToSwiftPwaPageModule", function() { return GoToSwiftPwaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _go_to_swift_pwa_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./go-to-swift-pwa.page */ "./src/app/go-to-swift-pwa/go-to-swift-pwa.page.ts");







const routes = [
    {
        path: '',
        component: _go_to_swift_pwa_page__WEBPACK_IMPORTED_MODULE_6__["GoToSwiftPwaPage"]
    }
];
let GoToSwiftPwaPageModule = class GoToSwiftPwaPageModule {
};
GoToSwiftPwaPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_go_to_swift_pwa_page__WEBPACK_IMPORTED_MODULE_6__["GoToSwiftPwaPage"]]
    })
], GoToSwiftPwaPageModule);



/***/ }),

/***/ "./src/app/go-to-swift-pwa/go-to-swift-pwa.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/go-to-swift-pwa/go-to-swift-pwa.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2dvLXRvLXN3aWZ0LXB3YS9nby10by1zd2lmdC1wd2EucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/go-to-swift-pwa/go-to-swift-pwa.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/go-to-swift-pwa/go-to-swift-pwa.page.ts ***!
  \*********************************************************/
/*! exports provided: GoToSwiftPwaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoToSwiftPwaPage", function() { return GoToSwiftPwaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let GoToSwiftPwaPage = class GoToSwiftPwaPage {
    constructor() { }
    ngOnInit() {
    }
};
GoToSwiftPwaPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-go-to-swift-pwa',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./go-to-swift-pwa.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/go-to-swift-pwa/go-to-swift-pwa.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./go-to-swift-pwa.page.scss */ "./src/app/go-to-swift-pwa/go-to-swift-pwa.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], GoToSwiftPwaPage);



/***/ })

}]);
//# sourceMappingURL=go-to-swift-pwa-go-to-swift-pwa-module-es2015.js.map