(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["withdraw-funds-withdraw-funds-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/withdraw-funds/withdraw-funds.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/withdraw-funds/withdraw-funds.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar>\n        <ion-title text-center>Request Confirmation</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\" [sizeLg]=\"8\" [offsetLg]=\"2\">\n                <ion-card>\n                    <ion-card-content text-center>\n                        You are about to request for a commission of amount GH¢\n                        {{withdrawalAmount}},<br />\n                        which will be sent to mobile number {{phoneNumber}}.\n                        <br />\n                        Enter the PIN sent to your mobile number to confirm your\n                        identity and to validate this transaction\n                        <form\n                            [formGroup]=\"withdrawFundsForm\"\n                            (submit)=\"withdrawFunds(withdrawFundsForm)\"\n                        >\n                            <ion-item>\n                                <ion-label [position]=\"'stacked'\"\n                                    >Enter PIN</ion-label\n                                >\n                                <ion-input\n                                    type=\"text\"\n                                    [formControlName]=\"'otp'\"\n                                    minlength=\"6\"\n                                    required\n                                ></ion-input>\n                            </ion-item>\n                            <ion-button\n                                [expand]=\"'block'\"\n                                type=\"submit\"\n                                [disabled]=\"withdrawFundsForm.invalid\"\n                                >Withdraw Funds</ion-button\n                            >\n                        </form>\n                    </ion-card-content>\n                </ion-card>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/withdraw-funds/withdraw-funds.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/withdraw-funds/withdraw-funds.module.ts ***!
  \*********************************************************/
/*! exports provided: WithdrawFundsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WithdrawFundsPageModule", function() { return WithdrawFundsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _withdraw_funds_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./withdraw-funds.page */ "./src/app/withdraw-funds/withdraw-funds.page.ts");







const routes = [
    {
        path: '',
        component: _withdraw_funds_page__WEBPACK_IMPORTED_MODULE_6__["WithdrawFundsPage"],
    },
];
let WithdrawFundsPageModule = class WithdrawFundsPageModule {
};
WithdrawFundsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes),
        ],
        declarations: [_withdraw_funds_page__WEBPACK_IMPORTED_MODULE_6__["WithdrawFundsPage"]],
    })
], WithdrawFundsPageModule);



/***/ }),

/***/ "./src/app/withdraw-funds/withdraw-funds.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/withdraw-funds/withdraw-funds.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3dpdGhkcmF3LWZ1bmRzL3dpdGhkcmF3LWZ1bmRzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/withdraw-funds/withdraw-funds.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/withdraw-funds/withdraw-funds.page.ts ***!
  \*******************************************************/
/*! exports provided: WithdrawFundsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WithdrawFundsPage", function() { return WithdrawFundsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _withdraw_funds_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./withdraw-funds.service */ "./src/app/withdraw-funds/withdraw-funds.service.ts");
/* harmony import */ var _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.service */ "./src/app/shared/shared.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");






let WithdrawFundsPage = class WithdrawFundsPage {
    constructor(fb, withDrawFundsService, shared, router) {
        this.fb = fb;
        this.withDrawFundsService = withDrawFundsService;
        this.shared = shared;
        this.router = router;
    }
    ngOnInit() {
        this.withdrawalAmount = sessionStorage.getItem('withdrawalAmount');
        this.phoneNumber = this.shared.getPhoneNumber();
        this.withdrawFundsForm = this.fb.group({
            amount: [
                this.withdrawalAmount,
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]),
            ],
            otp: [
                '',
                _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].compose([
                    _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].minLength(6),
                    _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required,
                ]),
            ],
        });
    }
    withdrawFunds(form) {
        this.withDrawFundsService.withdrawFunds(form.value).subscribe(response => {
            sessionStorage.setItem('withdrawalResponse', response.Message);
            this.router.navigate(['confirm-commission-withdrawal']);
        }, error => this.shared.presentToast('Withdrawal Failed'));
    }
};
WithdrawFundsPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"] },
    { type: _withdraw_funds_service__WEBPACK_IMPORTED_MODULE_3__["WithdrawFundsService"] },
    { type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
WithdrawFundsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-withdraw-funds',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./withdraw-funds.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/withdraw-funds/withdraw-funds.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./withdraw-funds.page.scss */ "./src/app/withdraw-funds/withdraw-funds.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormBuilder"],
        _withdraw_funds_service__WEBPACK_IMPORTED_MODULE_3__["WithdrawFundsService"],
        _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
], WithdrawFundsPage);



/***/ }),

/***/ "./src/app/withdraw-funds/withdraw-funds.service.ts":
/*!**********************************************************!*\
  !*** ./src/app/withdraw-funds/withdraw-funds.service.ts ***!
  \**********************************************************/
/*! exports provided: WithdrawFundsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WithdrawFundsService", function() { return WithdrawFundsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");





let WithdrawFundsService = class WithdrawFundsService {
    constructor(http) {
        this.http = http;
    }
    withdrawFunds(data) {
        const httpParams = { fromObject: data };
        const options = { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"](httpParams) };
        return this.http
            .post(`${src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi}/dalexpaddies/withdrawFunds`, null, options)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["throttleTime"])(10000));
    }
};
WithdrawFundsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
WithdrawFundsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], WithdrawFundsService);



/***/ })

}]);
//# sourceMappingURL=withdraw-funds-withdraw-funds-module-es2015.js.map