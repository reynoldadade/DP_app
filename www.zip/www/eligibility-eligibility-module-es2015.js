(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["eligibility-eligibility-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/eligibility/eligibility.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/eligibility/eligibility.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar [color]=\"'primary'\">\n      <ion-buttons slot=\"start\">\n          <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-buttons slot=\"end\">\n          <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    <ion-title class=\"ion-text-center\">Credit Check</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n          <form [formGroup]=\"eligibilityForm\" (submit)=\"creditCheck(eligibilityForm)\">\n            <ion-item>\n              <ion-label [position]=\"'stacked'\">Employee Id</ion-label>\n              <ion-input type=\"text\" [formControlName]=\"'staffId'\"></ion-input>\n            </ion-item>\n            <ion-button [expand]=\"'full'\" type=\"submit\" [disabled]=\"eligibilityForm.invalid\">Search <ion-spinner *ngIf=\"spinner\"></ion-spinner></ion-button>\n          </form>\n          <ion-list>\n            <ion-item *ngIf=\"message\">\n              <ion-label class=\"ion-text-center eligibility\">CLIENT IS {{eligibility?.Status}}</ion-label>\n            </ion-item>\n            <div  *ngIf=\"eligible\">\n                <ion-item>\n                    <ion-label class=\"eligibility\">Staff Name: {{eligibility?.FullName}}</ion-label>\n                </ion-item>\n                <ion-item>\n                    <ion-label class=\" eligibility\">Staff Id: {{eligibility?.EmployeeID}}</ion-label>\n                </ion-item>\n                <ion-item>\n                    <ion-label class=\"eligibility\">Age: {{eligibility?.Age}}</ion-label>\n                </ion-item>\n                <ion-item>\n                    <ion-label class=\"eligibility\">Tenor: {{eligibility?.Tenor}}</ion-label>\n                </ion-item>\n            </div>\n          </ion-list>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/eligibility/eligibility.module.ts":
/*!***************************************************!*\
  !*** ./src/app/eligibility/eligibility.module.ts ***!
  \***************************************************/
/*! exports provided: EligibilityPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EligibilityPageModule", function() { return EligibilityPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _eligibility_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./eligibility.page */ "./src/app/eligibility/eligibility.page.ts");







const routes = [
    {
        path: '',
        component: _eligibility_page__WEBPACK_IMPORTED_MODULE_6__["EligibilityPage"]
    }
];
let EligibilityPageModule = class EligibilityPageModule {
};
EligibilityPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_eligibility_page__WEBPACK_IMPORTED_MODULE_6__["EligibilityPage"]]
    })
], EligibilityPageModule);



/***/ }),

/***/ "./src/app/eligibility/eligibility.page.scss":
/*!***************************************************!*\
  !*** ./src/app/eligibility/eligibility.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".eligibility {\n  font-size: small;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWxpZ2liaWxpdHkvRTpcXERBTEVYIENPREVcXGRwQXBwMi9zcmNcXGFwcFxcZWxpZ2liaWxpdHlcXGVsaWdpYmlsaXR5LnBhZ2Uuc2NzcyIsInNyYy9hcHAvZWxpZ2liaWxpdHkvZWxpZ2liaWxpdHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL2VsaWdpYmlsaXR5L2VsaWdpYmlsaXR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lbGlnaWJpbGl0eXtcclxuICBmb250LXNpemU6IHNtYWxsO1xyXG59IiwiLmVsaWdpYmlsaXR5IHtcbiAgZm9udC1zaXplOiBzbWFsbDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/eligibility/eligibility.page.ts":
/*!*************************************************!*\
  !*** ./src/app/eligibility/eligibility.page.ts ***!
  \*************************************************/
/*! exports provided: EligibilityPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EligibilityPage", function() { return EligibilityPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _eligibility_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./eligibility.service */ "./src/app/eligibility/eligibility.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../shared/shared.service */ "./src/app/shared/shared.service.ts");





let EligibilityPage = class EligibilityPage {
    constructor(eligibilityService, fb, sharedService) {
        this.eligibilityService = eligibilityService;
        this.fb = fb;
        this.sharedService = sharedService;
        this.message = false;
        this.spinner = false;
    }
    ngOnInit() {
        this.eligibilityForm = this.fb.group({
            staffId: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
        });
    }
    creditCheck(form) {
        this.spinner = true;
        this.eligible = false;
        this.message = false;
        this.eligibilityService.creditCheck(form.value).subscribe(response => {
            this.message = true;
            if (response.Status === 'true') {
                this.eligibility = JSON.parse(response.Data);
                if (this.eligibility.Status === 'ELIGIBLE') {
                    this.eligible = true;
                }
            }
            else {
                this.sharedService.presentToast('Client Not Found');
            }
        }, error => {
            this.spinner = false;
            this.sharedService.presentToast('Network Error');
        }, () => (this.spinner = false));
    }
};
EligibilityPage.ctorParameters = () => [
    { type: _eligibility_service__WEBPACK_IMPORTED_MODULE_2__["EligibilityService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"] }
];
EligibilityPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-eligibility',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./eligibility.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/eligibility/eligibility.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./eligibility.page.scss */ "./src/app/eligibility/eligibility.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_eligibility_service__WEBPACK_IMPORTED_MODULE_2__["EligibilityService"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
        _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]])
], EligibilityPage);



/***/ }),

/***/ "./src/app/eligibility/eligibility.service.ts":
/*!****************************************************!*\
  !*** ./src/app/eligibility/eligibility.service.ts ***!
  \****************************************************/
/*! exports provided: EligibilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EligibilityService", function() { return EligibilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");




let EligibilityService = class EligibilityService {
    constructor(http) {
        this.http = http;
    }
    creditCheck(data) {
        const httpParams = { fromObject: data };
        const options = { params: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"](httpParams) };
        return this.http.post(`${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi}/mobile/creditcheck`, null, options);
    }
};
EligibilityService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
EligibilityService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], EligibilityService);



/***/ })

}]);
//# sourceMappingURL=eligibility-eligibility-module-es2015.js.map