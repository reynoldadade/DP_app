function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["selfie-token-selfie-token-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/selfie-token/selfie-token.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/selfie-token/selfie-token.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSelfieTokenSelfieTokenPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n          <ion-card>\n            <ion-card-header class=\"ion-text-center\" [color]=\"'primary'\">\n              Token\n            </ion-card-header>\n            <ion-card-content>\n              <ion-item class=\"ion-text-center ion-margin\">\n                <ion-input [readonly]=\"true\" [value]=\"token\" id=\"selfieToken\">\n                </ion-input>\n                <ion-spinner *ngIf=\"spinner\" slot=\"end\"></ion-spinner>\n              </ion-item>\n              <ion-button [expand]=\"'full'\" (click)=\"getToken()\">Generate a new token</ion-button>\n                <ion-button [expand]=\"'full'\" (click)=\"copyToClipboard(token)\">Copy <ion-icon name=\"copy\"></ion-icon></ion-button>\n            </ion-card-content>\n          </ion-card>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/selfie-token/selfie-token.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/selfie-token/selfie-token.module.ts ***!
    \*****************************************************/

  /*! exports provided: SelfieTokenPageModule */

  /***/
  function srcAppSelfieTokenSelfieTokenModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelfieTokenPageModule", function () {
      return SelfieTokenPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _selfie_token_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./selfie-token.page */
    "./src/app/selfie-token/selfie-token.page.ts");

    var routes = [{
      path: '',
      component: _selfie_token_page__WEBPACK_IMPORTED_MODULE_6__["SelfieTokenPage"]
    }];

    var SelfieTokenPageModule = function SelfieTokenPageModule() {
      _classCallCheck(this, SelfieTokenPageModule);
    };

    SelfieTokenPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_selfie_token_page__WEBPACK_IMPORTED_MODULE_6__["SelfieTokenPage"]]
    })], SelfieTokenPageModule);
    /***/
  },

  /***/
  "./src/app/selfie-token/selfie-token.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/selfie-token/selfie-token.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSelfieTokenSelfieTokenPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NlbGZpZS10b2tlbi9zZWxmaWUtdG9rZW4ucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/selfie-token/selfie-token.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/selfie-token/selfie-token.page.ts ***!
    \***************************************************/

  /*! exports provided: SelfieTokenPage */

  /***/
  function srcAppSelfieTokenSelfieTokenPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelfieTokenPage", function () {
      return SelfieTokenPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _shared_shared_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../shared/shared.service */
    "./src/app/shared/shared.service.ts");
    /* harmony import */


    var _selfie_token_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./selfie-token.service */
    "./src/app/selfie-token/selfie-token.service.ts");

    var SelfieTokenPage =
    /*#__PURE__*/
    function () {
      function SelfieTokenPage(sharedService, selfieTokenService) {
        _classCallCheck(this, SelfieTokenPage);

        this.sharedService = sharedService;
        this.selfieTokenService = selfieTokenService;
        this.token = '';
      }

      _createClass(SelfieTokenPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.spinner = true;
          this.user = sessionStorage.getItem('userCode');
          console.log(this.user);

          if (this.user) {
            this.getToken();
          } else {
            this.sharedService.presentToast('Login to generate token');
            this.spinner = false;
          }
        }
      }, {
        key: "copyToClipboard",
        value: function copyToClipboard(item) {
          document.addEventListener('copy', function (e) {
            e.clipboardData.setData('text/plain', item);
            e.preventDefault();
            document.removeEventListener('copy', null);
          });
          document.execCommand('copy');
          this.sharedService.presentToast("copied token: ".concat(item));
        }
      }, {
        key: "getToken",
        value: function getToken() {
          var _this = this;

          this.spinner = true;
          this.selfieTokenService.getToken(this.user).subscribe(function (response) {
            _this.token = response;
            console.log(response);
            _this.spinner = false;
          }, function (error1) {
            console.log(error1);

            _this.sharedService.presentToast('Network Error');

            _this.spinner = false;
          });
        }
      }]);

      return SelfieTokenPage;
    }();

    SelfieTokenPage.ctorParameters = function () {
      return [{
        type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"]
      }, {
        type: _selfie_token_service__WEBPACK_IMPORTED_MODULE_3__["SelfieTokenService"]
      }];
    };

    SelfieTokenPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-selfie-token',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./selfie-token.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/selfie-token/selfie-token.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./selfie-token.page.scss */
      "./src/app/selfie-token/selfie-token.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_shared_shared_service__WEBPACK_IMPORTED_MODULE_2__["SharedService"], _selfie_token_service__WEBPACK_IMPORTED_MODULE_3__["SelfieTokenService"]])], SelfieTokenPage);
    /***/
  },

  /***/
  "./src/app/selfie-token/selfie-token.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/selfie-token/selfie-token.service.ts ***!
    \******************************************************/

  /*! exports provided: SelfieTokenService */

  /***/
  function srcAppSelfieTokenSelfieTokenServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SelfieTokenService", function () {
      return SelfieTokenService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../environments/environment */
    "./src/environments/environment.ts");

    var SelfieTokenService =
    /*#__PURE__*/
    function () {
      function SelfieTokenService(http) {
        _classCallCheck(this, SelfieTokenService);

        this.http = http;
      }

      _createClass(SelfieTokenService, [{
        key: "getToken",
        value: function getToken(userId) {
          return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi, "/mobile/v2/SelfieToken/generate/").concat(userId));
        }
      }]);

      return SelfieTokenService;
    }();

    SelfieTokenService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    SelfieTokenService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], SelfieTokenService);
    /***/
  }
}]);
//# sourceMappingURL=selfie-token-selfie-token-module-es5.js.map