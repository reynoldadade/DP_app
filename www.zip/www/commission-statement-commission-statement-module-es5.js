function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["commission-statement-commission-statement-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/commission-statement/commission-statement.page.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/commission-statement/commission-statement.page.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCommissionStatementCommissionStatementPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar>\n        <ion-title text-center>Account Statement</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n                <ion-card>\n                    <ion-card-content>\n                        <form\n                            [formGroup]=\"ledgerForm\"\n                            (submit)=\"getAgentLedger(ledgerForm)\"\n                        >\n                            <ion-item>\n                                <ion-label>Start Date</ion-label>\n                                <ion-datetime\n                                    placeholder=\"Select Date\"\n                                    [formControlName]=\"'startDate'\"\n                                    [max]=\"today\"\n                                ></ion-datetime>\n                            </ion-item>\n                            <ion-item>\n                                <ion-label>End Date</ion-label>\n                                <ion-datetime\n                                    placeholder=\"Select Date\"\n                                    [formControlName]=\"'endDate'\"\n                                ></ion-datetime>\n                            </ion-item>\n                            <ion-button\n                                [expand]=\"'full'\"\n                                type=\"submit\"\n                                [disabled]=\"ledgerForm.invalid\"\n                            >\n                                Search transactions<ion-spinner\n                                    *ngIf=\"spinner\"\n                                ></ion-spinner>\n                            </ion-button>\n                        </form>\n                    </ion-card-content>\n                </ion-card>\n            </ion-col>\n        </ion-row>\n\n        <ion-row>\n            <ion-col [sizeMd]=\"4\" [offsetMd]=\"4\">\n                <ion-list>\n                    <ion-item *ngFor=\"let transaction of ledger\">\n                        <ion-label class=\"eligibility\">\n                            <h2>\n                                Date:\n                                {{transaction.Posting_Date|date:'shortDate'}}\n                            </h2>\n                            <h2>Amount: {{transaction.Amount}}</h2>\n                            <h2>Reason: {{transaction.Description}}</h2>\n                        </ion-label>\n                    </ion-item>\n                </ion-list>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/commission-statement/commission-statement.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/commission-statement/commission-statement.module.ts ***!
    \*********************************************************************/

  /*! exports provided: CommissionStatementPageModule */

  /***/
  function srcAppCommissionStatementCommissionStatementModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionStatementPageModule", function () {
      return CommissionStatementPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _commission_statement_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./commission-statement.page */
    "./src/app/commission-statement/commission-statement.page.ts");

    var routes = [{
      path: '',
      component: _commission_statement_page__WEBPACK_IMPORTED_MODULE_6__["CommissionStatementPage"]
    }];

    var CommissionStatementPageModule = function CommissionStatementPageModule() {
      _classCallCheck(this, CommissionStatementPageModule);
    };

    CommissionStatementPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_commission_statement_page__WEBPACK_IMPORTED_MODULE_6__["CommissionStatementPage"]]
    })], CommissionStatementPageModule);
    /***/
  },

  /***/
  "./src/app/commission-statement/commission-statement.page.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/commission-statement/commission-statement.page.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCommissionStatementCommissionStatementPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbW1pc3Npb24tc3RhdGVtZW50L2NvbW1pc3Npb24tc3RhdGVtZW50LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/commission-statement/commission-statement.page.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/commission-statement/commission-statement.page.ts ***!
    \*******************************************************************/

  /*! exports provided: CommissionStatementPage */

  /***/
  function srcAppCommissionStatementCommissionStatementPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionStatementPage", function () {
      return CommissionStatementPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _commission_statement_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./commission-statement.service */
    "./src/app/commission-statement/commission-statement.service.ts");
    /* harmony import */


    var _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../shared/shared.service */
    "./src/app/shared/shared.service.ts");

    var CommissionStatementPage =
    /*#__PURE__*/
    function () {
      function CommissionStatementPage(fb, csService, shared) {
        _classCallCheck(this, CommissionStatementPage);

        this.fb = fb;
        this.csService = csService;
        this.shared = shared;
        this.today = new Date().toISOString();
      }

      _createClass(CommissionStatementPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.ledgerForm = this.fb.group({
            startDate: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            endDate: [this.today, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
          });
        }
      }, {
        key: "getAgentLedger",
        value: function getAgentLedger(form) {
          var _this = this;

          this.spinner = true;
          this.ledger = [];
          this.csService.getAgentLegder(form.value).subscribe(function (response) {
            _this.ledger = response;

            if (response.length === 0) {
              _this.shared.presentToast('No transactions found for this duration');
            }

            _this.spinner = false;
          }, function (err) {
            _this.spinner = false;

            _this.shared.presentToast('Failed to get statement');
          });
        }
      }]);

      return CommissionStatementPage;
    }();

    CommissionStatementPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _commission_statement_service__WEBPACK_IMPORTED_MODULE_3__["CommissionStatementService"]
      }, {
        type: _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]
      }];
    };

    CommissionStatementPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-commission-statement',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./commission-statement.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/commission-statement/commission-statement.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./commission-statement.page.scss */
      "./src/app/commission-statement/commission-statement.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _commission_statement_service__WEBPACK_IMPORTED_MODULE_3__["CommissionStatementService"], _shared_shared_service__WEBPACK_IMPORTED_MODULE_4__["SharedService"]])], CommissionStatementPage);
    /***/
  },

  /***/
  "./src/app/commission-statement/commission-statement.service.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/commission-statement/commission-statement.service.ts ***!
    \**********************************************************************/

  /*! exports provided: CommissionStatementService */

  /***/
  function srcAppCommissionStatementCommissionStatementServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CommissionStatementService", function () {
      return CommissionStatementService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var CommissionStatementService =
    /*#__PURE__*/
    function () {
      function CommissionStatementService(http) {
        _classCallCheck(this, CommissionStatementService);

        this.http = http;
      }

      _createClass(CommissionStatementService, [{
        key: "getAgentLegder",
        value: function getAgentLegder(dateParams) {
          var params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]().append('startDate', dateParams.startDate.toString()).append('endDate', dateParams.endDate.toString());
          var options = {
            params: params
          };
          return this.http.get("".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].filmsApi, "/dalexpaddies/agentLedger"), options);
        }
      }]);

      return CommissionStatementService;
    }();

    CommissionStatementService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    CommissionStatementService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], CommissionStatementService);
    /***/
  }
}]);
//# sourceMappingURL=commission-statement-commission-statement-module-es5.js.map