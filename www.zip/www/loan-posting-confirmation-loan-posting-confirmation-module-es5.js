function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["loan-posting-confirmation-loan-posting-confirmation-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/loan-posting-confirmation/loan-posting-confirmation.page.html":
  /*!*********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/loan-posting-confirmation/loan-posting-confirmation.page.html ***!
    \*********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoanPostingConfirmationLoanPostingConfirmationPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar>\n        <ion-title>Loan Details</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-grid>\n        <ion-row>\n            <ion-col [sizeMd]=\"8\" [offsetMd]=\"2\">\n                <ion-list>\n                    <ion-item>\n                        Request Id : {{loanRequestResponse?.Id}}\n                    </ion-item>\n                    <ion-item>\n                        Name : {{loanRequestResponse?.ClientName}}\n                    </ion-item>\n                    <ion-item>\n                        Gross : {{loanRequestResponse?.GrossAmount}}\n                    </ion-item>\n                    <ion-item>\n                        Net : {{loanRequestResponse?.NetAmount}}\n                    </ion-item>\n                </ion-list>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>\n";
    /***/
  },

  /***/
  "./src/app/loan-posting-confirmation/loan-posting-confirmation.module.ts":
  /*!*******************************************************************************!*\
    !*** ./src/app/loan-posting-confirmation/loan-posting-confirmation.module.ts ***!
    \*******************************************************************************/

  /*! exports provided: LoanPostingConfirmationPageModule */

  /***/
  function srcAppLoanPostingConfirmationLoanPostingConfirmationModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoanPostingConfirmationPageModule", function () {
      return LoanPostingConfirmationPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _loan_posting_confirmation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./loan-posting-confirmation.page */
    "./src/app/loan-posting-confirmation/loan-posting-confirmation.page.ts");

    var routes = [{
      path: '',
      component: _loan_posting_confirmation_page__WEBPACK_IMPORTED_MODULE_6__["LoanPostingConfirmationPage"]
    }];

    var LoanPostingConfirmationPageModule = function LoanPostingConfirmationPageModule() {
      _classCallCheck(this, LoanPostingConfirmationPageModule);
    };

    LoanPostingConfirmationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
      declarations: [_loan_posting_confirmation_page__WEBPACK_IMPORTED_MODULE_6__["LoanPostingConfirmationPage"]]
    })], LoanPostingConfirmationPageModule);
    /***/
  },

  /***/
  "./src/app/loan-posting-confirmation/loan-posting-confirmation.page.scss":
  /*!*******************************************************************************!*\
    !*** ./src/app/loan-posting-confirmation/loan-posting-confirmation.page.scss ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoanPostingConfirmationLoanPostingConfirmationPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvYW4tcG9zdGluZy1jb25maXJtYXRpb24vbG9hbi1wb3N0aW5nLWNvbmZpcm1hdGlvbi5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/loan-posting-confirmation/loan-posting-confirmation.page.ts":
  /*!*****************************************************************************!*\
    !*** ./src/app/loan-posting-confirmation/loan-posting-confirmation.page.ts ***!
    \*****************************************************************************/

  /*! exports provided: LoanPostingConfirmationPage */

  /***/
  function srcAppLoanPostingConfirmationLoanPostingConfirmationPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoanPostingConfirmationPage", function () {
      return LoanPostingConfirmationPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var LoanPostingConfirmationPage =
    /*#__PURE__*/
    function () {
      function LoanPostingConfirmationPage() {
        _classCallCheck(this, LoanPostingConfirmationPage);
      }

      _createClass(LoanPostingConfirmationPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.loanRequestResponse = JSON.parse(sessionStorage.getItem('loanRequestResponse'));
          this.imageResponse = JSON.parse(sessionStorage.getItem('imageResponse'));
        }
      }]);

      return LoanPostingConfirmationPage;
    }();

    LoanPostingConfirmationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-loan-posting-confirmation',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./loan-posting-confirmation.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/loan-posting-confirmation/loan-posting-confirmation.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./loan-posting-confirmation.page.scss */
      "./src/app/loan-posting-confirmation/loan-posting-confirmation.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], LoanPostingConfirmationPage);
    /***/
  }
}]);
//# sourceMappingURL=loan-posting-confirmation-loan-posting-confirmation-module-es5.js.map